# -*- coding: utf-8 -*-
"""
Generador completo, riguroso y 100% compatible con pdfLaTeX en Overleaf
de guion_presentacion.tex
Autora: Valentina Oundjian (Licenciatura en Astronomía, UdelaR)
"""

import os
import re

def escape_inline_latex(s):
    # Reemplazar emojis por descripciones textuales limpias para pdflatex
    s = s.replace("🔴", "[Rojo] ")
    s = s.replace("🟢", "[Verde] ")
    s = s.replace("🎯", "[Caso Testigo] ")
    s = s.replace("⏱️", "")
    s = s.replace("🎬", "")
    s = s.replace("💡", "")

    # Proteger fórmulas matemáticas $...$
    math_tokens = []
    def save_math(m):
        math_tokens.append(m.group(0))
        return f"@@MATH{len(math_tokens)-1}@@"
    s = re.sub(r'\$[^\$]+\$', save_math, s)
    
    # Proteger código en línea `...`
    code_tokens = []
    def save_code(m):
        code_tokens.append(m.group(1))
        return f"@@CODE{len(code_tokens)-1}@@"
    s = re.sub(r'`([^`]+)`', save_code, s)
    
    # Escapes de caracteres especiales de LaTeX
    s = s.replace('&', r'\&')
    s = s.replace('%', r'\%')
    s = s.replace('#', r'\#')
    s = s.replace('_', r'\_')
    
    # Negritas y cursivas de markdown
    s = re.sub(r'\*\*([^\*]+)\*\*', r'\\textbf{\1}', s)
    s = re.sub(r'\*([^\*]+)\*', r'\\textit{\1}', s)
    
    # Comillas dobles
    s = s.replace('"', "''")
    
    # Restaurar código
    for i, c in enumerate(code_tokens):
        c_esc = c.replace('&', r'\&').replace('%', r'\%').replace('#', r'\#').replace('_', r'\_')
        s = s.replace(f"@@CODE{i}@@", f"\\texttt{{{c_esc}}}")
        
    # Restaurar matemáticas
    for i, m in enumerate(math_tokens):
        s = s.replace(f"@@MATH{i}@@", m)
        
    return s

def clean_paragraph_text(p):
    p = p.strip()
    if p.startswith('"') and p.endswith('"'):
        p = p[1:-1].strip()
    elif p.startswith('"'):
        p = p[1:].strip()
    elif p.endswith('"'):
        p = p[:-1].strip()
    return escape_inline_latex(p)

def generate_tex():
    md_path = r"C:\Users\valen\.gemini\antigravity\scratch\nbody_sim\GUION_MONOLOGO_20MIN.md"
    tex_path = r"C:\Users\valen\.gemini\antigravity\scratch\nbody_sim\guion_presentacion.tex"
    
    with open(md_path, "r", encoding="utf-8") as f:
        md_text = f.read()
        
    sections_raw = re.split(r"(### [^\n]+)", md_text)
    
    tex_parts = []
    
    # Header del archivo LaTeX
    tex_parts.append(r"""\documentclass[11pt,a4paper]{article}

% --- Idioma, Codificación y Tipografía ---
\usepackage[spanish, es-tabla, es-nodecimaldot]{babel}
\usepackage[utf8]{inputenc}
\usepackage[T1]{fontenc}
\usepackage{lmodern}
\usepackage{microtype}

% --- Geometría de Página ---
\usepackage[
  top=2.2cm,
  bottom=2.2cm,
  left=2.2cm,
  right=2.2cm,
  headheight=15pt,
  footskip=25pt
]{geometry}

% --- Paquetes Matemáticos y Símbolos ---
\usepackage{amsmath, amssymb}

% --- Colores Avanzados ---
\usepackage{xcolor}
\definecolor{navyMain}{HTML}{1E3A8A}      % Azul marino institucional
\definecolor{navyLight}{HTML}{EFF6FF}     % Fondo azul muy suave
\definecolor{navyBorder}{HTML}{3B82F6}    % Azul borde
\definecolor{timeBadge}{HTML}{B91C1C}     % Rojo tiempo / badge
\definecolor{cuePurple}{HTML}{6D28D9}     % Violeta para actuación
\definecolor{cueBg}{HTML}{F5F3FF}         % Fondo violeta suave
\definecolor{demoGreen}{HTML}{047857}     % Verde para acciones demo
\definecolor{demoBg}{HTML}{ECFDF5}        % Fondo verde suave
\definecolor{speechDark}{HTML}{0F172A}    % Slate 900 para lectura nítida
\definecolor{codeBg}{HTML}{F1F5F9}        % Gris código
\definecolor{barColor}{HTML}{94A3B8}      % Barra lateral de cita

% --- Cajas y Entornos con tcolorbox ---
\usepackage[most]{tcolorbox}
\tcbuselibrary{skins, breakable}

% Caja para diapositivas proyectadas
\newtcolorbox{diapositiva}[2][]{
  enhanced,
  colback=navyLight,
  colframe=navyBorder,
  boxrule=1.1pt,
  arc=2.5mm,
  left=10pt, right=10pt, top=6pt, bottom=6pt,
  fonttitle=\bfseries\sffamily\small\color{white},
  colbacktitle=navyMain,
  title={\textsc{Proyectar en Pantalla: #2}},
  #1
}

% Indicación escénica / corporal / pausas
\newtcolorbox{indicacion}[1][]{
  enhanced,
  colback=cueBg,
  colframe=cuePurple!70!black,
  boxrule=0.8pt,
  arc=2mm,
  left=8pt, right=8pt, top=4pt, bottom=4pt,
  fontupper=\small\sffamily\itshape\color{cuePurple!90!black},
  #1
}

% Acción en vivo en la pantalla de la simulación
\newtcolorbox{acciondemo}[1][]{
  enhanced,
  colback=demoBg,
  colframe=demoGreen,
  boxrule=1pt,
  arc=2mm,
  left=8pt, right=8pt, top=5pt, bottom=5pt,
  fontupper=\small\sffamily\bfseries\color{demoGreen!90!black},
  #1
}

% Discurso palabra por palabra (alta legibilidad)
\newtcolorbox{discurso}[1][]{
  enhanced,
  breakable,
  colback=white,
  colframe=barColor,
  boxrule=0pt,
  leftrule=3.5pt,
  arc=0mm,
  left=12pt, right=8pt, top=6pt, bottom=6pt,
  fontupper=\normalsize\rmfamily\color{speechDark}\linespread{1.22}\selectfont,
  #1
}

% Pregunta/Respuesta del Machete de Defensa
\newtcolorbox{macheteitem}[2][]{
  enhanced,
  breakable,
  colback=white,
  colframe=navyMain,
  boxrule=1pt,
  arc=2.5mm,
  left=10pt, right=10pt, top=6pt, bottom=6pt,
  fonttitle=\bfseries\sffamily\color{white},
  colbacktitle=navyMain,
  title={#2},
  #1
}

% Encabezado de Bloque con Badge de Tiempo
\newcommand{\minutobloque}[3]{%
  \vspace{0.45cm}%
  \noindent
  \begin{tcolorbox}[
    enhanced,
    colback=white,
    colframe=navyMain,
    boxrule=1pt,
    arc=2.5mm,
    left=8pt, right=8pt, top=6pt, bottom=6pt
  ]
    \tcbox[
      on line,
      colback=timeBadge,
      colframe=timeBadge,
      arc=1.5mm,
      boxrule=0pt,
      top=2pt, bottom=2pt, left=5pt, right=5pt
    ]{\color{white}\bfseries\sffamily\small #1}%
    \hspace{0.25cm}%
    {\large\bfseries\sffamily\color{navyMain} #2}%
    \hfill%
    {\small\sffamily\bfseries\color{gray!80!black} #3}%
  \end{tcolorbox}%
  \vspace{0.15cm}%
}

% --- Encabezados y Pies de Página ---
\usepackage{fancyhdr}
\usepackage{lastpage}
\pagestyle{fancy}
\fancyhf{}
\fancyhead[L]{\small\sffamily\color{gray!90!black}Valentina Oundjian --- Licenciatura en Astronomía (UdelaR)}
\fancyhead[R]{\small\sffamily\bfseries\color{navyMain}Defensa Final: Simulación Gravitatoria}
\fancyfoot[L]{\small\sffamily\color{gray!80!black}Guión Maestro Monólogo (20 Minutos)}
\fancyfoot[C]{\small\sffamily\color{gray!80!black}Computación 2026}
\fancyfoot[R]{\small\sffamily\bfseries\thepage\ de \pageref{LastPage}}
\renewcommand{\headrulewidth}{0.4pt}
\renewcommand{\footrulewidth}{0.4pt}

% --- Hipervínculos ---
\usepackage{hyperref}
\hypersetup{
  colorlinks=true,
  linkcolor=navyMain,
  urlcolor=navyMain,
  citecolor=navyMain
}

\begin{document}

% =========================================================================
% ENCABEZADO PRINCIPAL DEL DOCUMENTO
% =========================================================================
\begin{center}
  {\scshape\Large Universidad de la República --- Facultad de Ciencias}\\[0.15cm]
  {\large Licenciatura en Astronomía --- Curso de Computación 2026}\\[0.4cm]
  {\LARGE\bfseries\color{navyMain} Guión Maestro de Presentación Oral}\\[0.2cm]
  {\Large\bfseries Monólogo Palabra por Palabra (20 Minutos Exactos)}\\[0.25cm]
  {\itshape Simulación gravitatoria de un sistema planetario (1 estrella + 2 planetas en 2D)}\\[0.35cm]
  \textbf{Estudiante:} Valentina Oundjian \quad $\cdot$ \quad \textbf{Fecha de Defensa:} Noviembre 2026
\end{center}

\vspace{0.2cm}
\hrule height 1pt
\vspace{0.35cm}

% =========================================================================
% CAJA DE CONTEXTO Y DISTRIBUCIÓN DEL TIEMPO
% =========================================================================
\begin{tcolorbox}[
  enhanced,
  colback=navyLight,
  colframe=navyMain,
  boxrule=1pt,
  arc=2.5mm,
  left=10pt, right=10pt, top=8pt, bottom=8pt,
  title=\textbf{\sffamily HOJA DE RUTA Y ESTRUCTURA TEMPORAL OFICIAL (5 - 10 - 5)}
]
  \small\sffamily
  Este documento contiene el \textbf{texto literal palabra por palabra} para la exposición oral de 20 minutos ante el tribunal docente. Diseñado como un guión cinematográfico continuo, permite mantener un ritmo calmo y fluido (\textasciitilde 120--130 palabras/min) sin baches ni improvisación:
  \begin{itemize}[leftmargin=1.5em, itemsep=2pt, topsep=4pt]
    \item \textbf{Bloque 1 (00:00 a 05:00 --- 5 min): La Física del Problema.} Del problema analítico de Kepler/Newton al caos determinista de 3 cuerpos de Poincaré; intuición geométrica de la deriva de energía de Euler frente a la conservación simpléctica de Leapfrog.
    \item \textbf{Bloque 2 (05:00 a 15:00 --- 10 min): La Simulación en Marcha y Validación.} Demostración interactiva en vivo; arquitectura modular en 6 funciones de Python/NumPy; prueba analítica a mano $(-1, 0)$; conservación del momento a nivel $10^{-18}$; convergencia $\mathcal{O}(\Delta t)$.
    \item \textbf{Bloque 3 (15:00 a 20:00 --- 5 min): El Proceso con el Agente de IA.} Caso real del desvío arcade con Pygame y posterior reencauce a computación científica; auditoría con pruebas de lápiz y papel; resolución del escollo técnico en Python 3.14 (distutils); el agente como tutor conceptual.
  \end{itemize}
\end{tcolorbox}

\vspace{0.4cm}
""")

    metadata_bloques = [
        ("00:00 a 01:00", "Apertura y Hoja de Ruta", "Introducción (1 min)"),
        ("01:00 a 03:00", "De 2 Cuerpos al Caos de 3 Cuerpos", "Bloque 1: Física (2 min)"),
        ("03:00 a 05:00", "La Intuición Geométrica: ¿Por Qué Falla Euler?", "Bloque 1: Física (2 min)"),
        ("05:00 a 08:00", "Demostración Práctica en Vivo (Código en Marcha)", "Bloque 2: Simulación (3 min)"),
        ("08:00 a 10:30", "Cómo Está Armado el Código: Arquitectura Modular", "Bloque 2: Simulación (2.5 min)"),
        ("10:30 a 12:30", "Resultados del Sistema y Escala 1 a 1", "Bloque 2: Simulación (2 min)"),
        ("12:30 a 15:00", "Validación Física: ¿Cómo Sabemos que Está Bien?", "Bloque 2: Simulación (2.5 min)"),
        ("15:00 a 16:30", "El Proceso con el Agente: El Tropiezo con Pygame", "Bloque 3: Agente (1.5 min)"),
        ("16:30 a 18:00", "Auditoría Crítica y Problemas Técnicos", "Bloque 3: Agente (1.5 min)"),
        ("18:00 a 19:30", "El Agente como Tutor Conceptual", "Bloque 3: Agente (1.5 min)"),
        ("19:30 a 20:00", "Conclusiones Finales y Cierre", "Cierre (0.5 min)")
    ]

    for b_idx in range(11):
        raw_idx = 1 + b_idx * 2
        body_raw = sections_raw[raw_idx + 1].strip()
        tiempo, titulo, bloque_tag = metadata_bloques[b_idx]
        
        tex_parts.append(f"\n% -------------------------------------------------------------------------\n")
        tex_parts.append(f"% BLOQUE {b_idx + 1}: {titulo} ({tiempo})\n")
        tex_parts.append(f"% -------------------------------------------------------------------------\n")
        tex_parts.append(f"\\minutobloque{{{tiempo}}}{{{titulo}}}{{{bloque_tag}}}\n")
        
        lines = []
        for l in body_raw.splitlines():
            l_str = l.strip()
            if l_str.startswith('>'):
                l_str = l_str[1:].strip()
            lines.append(l_str)
            
        full_content = "\n".join(lines)
        paragraphs = [p.strip() for p in re.split(r'\n\s*\n', full_content) if p.strip()]
        
        for p in paragraphs:
            # Ignorar separadores markdown
            if p == '---':
                continue
                
            # 1. Indicación de apertura *(...)*
            if p.startswith('*(') and p.endswith(')*'):
                clean_p = clean_paragraph_text(p[2:-2])
                tex_parts.append(f"\\begin{{indicacion}}\n  \\textbf{{[POSTURA / ACTITUD]}} {clean_p}\n\\end{{indicacion}}\n\n")
            
            # 2. Diapositiva: `[SLIDE ...]` o `[PASAR A SLIDE ...]`
            elif p.startswith('`[SLIDE') or p.startswith('`[PASAR A SLIDE'):
                m = re.match(r'`\[(?:PASAR A )?SLIDE ([0-9]+):\s*(.+)\]`', p)
                if m:
                    num_slide = m.group(1)
                    nom_slide = escape_inline_latex(m.group(2).strip())
                    tex_parts.append(f"\\begin{{diapositiva}}{{{num_slide}: {nom_slide}}}\n  \\textbf{{Diapositiva {num_slide}:}} {nom_slide}\n\\end{{diapositiva}}\n\n")
                else:
                    clean_p = escape_inline_latex(p.replace('`[', '').replace(']`', ''))
                    tex_parts.append(f"\\begin{{diapositiva}}{{{clean_p}}}\n  {clean_p}\n\\end{{diapositiva}}\n\n")
            
            # 3. Acción interactiva demo: `[Hacer clic en ...]`
            elif p.startswith("`[Hacer clic en el botón") or p.startswith("`[Hacer clic"):
                clean_p = escape_inline_latex(p.replace('`[', '').replace(']`', ''))
                tex_parts.append(f"\\begin{{acciondemo}}\n  \\textbf{{[DEMO EN VIVO]}} {clean_p}\n\\end{{acciondemo}}\n\n")
            
            # 4. Pausa o gesto escénico: `[Pausa ...]` o `[Señalar ...]` o `[Sonreír]` o `[Hacer un gesto ...]`
            elif (p.startswith('`[Pausa') or p.startswith('`[Señalar') or 
                  p.startswith('`[Sonreír') or p.startswith('`[Hacer un gesto')):
                clean_p = escape_inline_latex(p.replace('`[', '').replace(']`', ''))
                tex_parts.append(f"\\begin{{indicacion}}\n  \\textbf{{[ACCIÓN / PAUSA]}} {clean_p}\n\\end{{indicacion}}\n\n")
            
            # 5. Texto de monólogo hablado
            else:
                clean_p = clean_paragraph_text(p)
                tex_parts.append(f"\\begin{{discurso}}\n  {clean_p}\n\\end{{discurso}}\n\n")

    # Machete de Defensa
    tex_parts.append(r"""% =========================================================================
% MACHETE DE DEFENSA FINAL: PREGUNTAS DEL TRIBUNAL DOCENTE
% =========================================================================
\vspace{0.4cm}
\begin{center}
  {\LARGE\bfseries\color{navyMain} Machete de Respuestas para Preguntas del Tribunal}\\[0.15cm]
  {\small\sffamily Respuestas preparadas con respaldo científico para responder con seguridad y firmeza}
\end{center}
\vspace{0.25cm}

\begin{macheteitem}{Pregunta Probable 1: ¿Por qué no usaste Runge-Kutta 4 (RK4) que es de orden 4?}
  \textbf{Respuesta recomendada ante el tribunal:}\\[0.15cm]
  \textit{<<Runge-Kutta 4 tiene un error de discretización local muy chico de orden 4, pero tampoco es un integrador simpléctico. Para misiones espaciales de pocos días funciona muy bien, pero a lo largo de miles de órbitas también acumula deriva secular espuria de energía. Leapfrog, aunque sea formalmente de segundo orden, es inmensamente superior para mecánica celeste a largo plazo porque conserva el volumen del espacio de fases (teorema de Liouville) y es estrictamente reversible en el tiempo.>>}
\end{macheteitem}

\vspace{0.3cm}

\begin{macheteitem}{Pregunta Probable 2: ¿Por qué no usaste el algoritmo de Barnes-Hut?}
  \textbf{Respuesta recomendada ante el tribunal:}\\[0.15cm]
  \textit{<<Porque para un sistema de 3 cuerpos, calcular todas las interacciones exactas requiere únicamente 3 operaciones ($N(N-1)/2$). El algoritmo de Barnes-Hut construye un árbol espacial (octree en 3D o quadtree en 2D) para agrupar partículas lejanas en multipolos; esa estructura tiene un sobrecosto que solo se amortiza cuando simulamos cúmulos o galaxias con miles de estrellas, donde pasar de $\mathcal{O}(N^2)$ a $\mathcal{O}(N \log N)$ es imprescindible para que el cálculo termine. En nuestro problema planetario, la fuerza exacta par a par es la opción científicamente correcta.>>}
\end{macheteitem}

\vspace{0.3cm}

\begin{macheteitem}{Demostración de Tests en la Terminal}
  Si el tribunal docente solicita ver las pruebas unitarias automáticas en tiempo real:
  \begin{center}
    \colorbox{codeBg}{\parbox{0.85\linewidth}{\centering\texttt{\large\bfseries python main.py --verificar}}}
  \end{center}
  \vspace{0.1cm}
  \small Las seis pruebas automatizadas correrán con \texttt{pytest} en menos de dos segundos, validando:
  \begin{enumerate}[leftmargin=2em, itemsep=1pt, topsep=2pt]
    \item Aceleración teórica calculada a mano: vector $(-1, 0)$ exacto.
    \item Prueba de 2 cuerpos de Kepler: órbita cerrada.
    \item Conservación del momento lineal al nivel $10^{-18}$ (límite de punto flotante de 64 bits).
    \item Deriva secular de Euler verificada experimentalmente (+8.7\%).
    \item Estabilidad simpléctica de Leapfrog con cota de error acotada.
    \item Detección y manejo seguro de colisiones (\texttt{ZeroDivisionError}).
  \end{enumerate}
\end{macheteitem}

\end{document}
""")

    full_tex = "".join(tex_parts)
    with open(tex_path, "w", encoding="utf-8") as f:
        f.write(full_tex)
        
    print(f"LaTeX document successfully generated: {tex_path}")

if __name__ == "__main__":
    generate_tex()
