"""
Simulación gravitatoria de un sistema planetario (1 estrella + 2 planetas)
Proyecto final: Computación - Facultad de Ciencias, UdelaR
Autora: Valentina Oundjian (2026)

Punto de entrada principal. Permite:
1. Ejecutar la simulación principal con Euler explícito y Leapfrog.
2. Comprobar todas las leyes de conservación y pruebas físicas.
3. Generar todas las figuras para el informe académico.
"""

import argparse
import sys
import numpy as np

from simulacion_planetaria import (
    condiciones_iniciales,
    simular,
    graficar_trayectorias,
    graficar_magnitudes_conservadas,
)
from pruebas_verificacion import (
    test_aceleracion_calculo_a_mano,
    test_deteccion_separacion_nula,
    test_dos_cuerpos_convergencia_euler,
    test_conservacion_momento_lineal_exacta,
    test_euler_apertura_orbital_y_ganancia_energia,
    test_leapfrog_vs_euler,
)
from generar_graficos_informe import (
    generar_figura_1_trayectorias_euler,
    generar_figura_2_magnitudes_euler,
    generar_figura_3_convergencia_paso_temporal,
    generar_figura_4_comparacion_euler_leapfrog,
)


def ejecutar_simulacion_principal():
    print("=======================================================================")
    print(" Simulación Gravitatoria: 1 Estrella + 2 Planetas (Facultad de Ciencias)")
    print(" Autora: Valentina Oundjian")
    print("=======================================================================\n")

    masas, pos_0, vel_0, T_ref, G = condiciones_iniciales("tres_cuerpos")
    dt = T_ref / 1000.0
    duracion_periodos = 10
    n_pasos = int(duracion_periodos * T_ref / dt)

    print(f"-> Parámetros de simulación:")
    print(f"   * Masas: Estrella = {masas[0]}, Planeta 1 = {masas[1]}, Planeta 2 = {masas[2]}")
    print(f"   * Período de referencia T_ref: {T_ref:.4f} t0")
    print(f"   * Paso temporal dt: {dt:.6f} t0 (T_ref / 1000)")
    print(f"   * Duración: {duracion_periodos} T_ref ({n_pasos} pasos)")

    print("\n-> Ejecutando integración con Euler explícito...")
    res_euler = simular(pos_0, vel_0, masas, dt=dt, n_pasos=n_pasos, metodo="euler", G=G)

    print("-> Ejecutando integración con Leapfrog (ampliación)...")
    res_leap = simular(pos_0, vel_0, masas, dt=dt, n_pasos=n_pasos, metodo="leapfrog", G=G)

    # Resultados y conservación
    max_dE_euler = np.max(np.abs(res_euler["delta_E"]))
    max_dE_leap = np.max(np.abs(res_leap["delta_E"]))
    max_dP_euler = np.max(np.linalg.norm(res_euler["momentos_P"] - res_euler["momentos_P"][0], axis=1))

    print("\n-----------------------------------------------------------------------")
    print(" RESULTADOS DE CONTROL FÍSICO Y NUMÉRICO:")
    print(f" 1. Conservación de Momento Lineal (Euler):   max |dP| = {max_dP_euler:.2e} (Exacta)")
    print(f" 2. Desviación relativa de Energía (Euler):   max |dE/E0| = {max_dE_euler:.3e} ({max_dE_euler*100:.2f}%)")
    print(f" 3. Desviación relativa de Energía (Leapfrog): max |dE/E0| = {max_dE_leap:.3e} ({max_dE_leap*100:.6f}%)")
    print("-----------------------------------------------------------------------")

    print("\n-> Generando gráficos para el trabajo en la carpeta 'graficos/'...")
    generar_figura_1_trayectorias_euler()
    generar_figura_2_magnitudes_euler()
    generar_figura_3_convergencia_paso_temporal()
    generar_figura_4_comparacion_euler_leapfrog()

    print("\n[OK] Simulación completada con éxito. Archivos generados listos para el informe.")


def ejecutar_pruebas():
    print("=======================================================================")
    print(" Ejecutando Suite de Pruebas de Verificación Física y Numérica")
    print("=======================================================================\n")
    test_aceleracion_calculo_a_mano()
    print("[1/6] Prueba de aceleración a mano: OK (a debida a masa en origen es (-1, 0))")
    
    test_deteccion_separacion_nula()
    print("[2/6] Detección de colisión / separación nula: OK")

    test_dos_cuerpos_convergencia_euler()
    print("[3/6] Prueba de 2 cuerpos y convergencia O(dt) de Euler: OK (razón ~ 2.0)")

    test_conservacion_momento_lineal_exacta()
    print("[4/6] Conservación exacta del momento lineal (P^{n+1} = P^n): OK (< 1e-15)")

    test_euler_apertura_orbital_y_ganancia_energia()
    print("[5/6] Apertura orbital y ganancia espuria de energía en Euler: OK (confirmada)")

    test_leapfrog_vs_euler()
    print("[6/6] Comparación de estabilidad con Leapfrog: OK (varios órdenes de magnitud superior)")

    print("\n[Éxito] Todas las comprobaciones físicas y numéricas fueron validadas.")


def main():
    parser = argparse.ArgumentParser(
        description="Simulación Gravitatoria de un Sistema Planetario - Valentina Oundjian (UdelaR)"
    )
    parser.add_argument(
        "--verificar",
        action="store_true",
        help="Ejecutar pruebas unitarias de verificación física y matemática",
    )
    parser.add_argument(
        "--graficos",
        action="store_true",
        help="Generar únicamente los gráficos del informe",
    )

    args = parser.parse_args()

    if args.verificar:
        ejecutar_pruebas()
    elif args.graficos:
        generar_figura_1_trayectorias_euler()
        generar_figura_2_magnitudes_euler()
        generar_figura_3_convergencia_paso_temporal()
        generar_figura_4_comparacion_euler_leapfrog()
    else:
        ejecutar_simulacion_principal()


if __name__ == "__main__":
    main()
