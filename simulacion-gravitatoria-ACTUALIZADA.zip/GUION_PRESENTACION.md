# 🎙️ Guion Calibrado para la Presentación Oral (Estructura 5 - 10 - 5)

**Proyecto Final:** Simulación Gravitatoria de un Sistema Planetario  
**Estudiante:** Valentina Oundjian  
**Asignatura:** Computación — Facultad de Ciencias, UdelaR (2026)  
**Duración Total:** 20 Minutos  
**Diapositivas:** [`presentacion.html`](presentacion.html)

---

## ⏱️ Cronómetro de la Exposición (20 Minutos Exactos)

| Bloque | Tema Principal | Diapositivas | Tiempo Asignado |
| :--- | :--- | :--- | :--- |
| **Apertura** | Saludo y mapa de ruta | Slide 1 | **1 minuto** (00:00 - 01:00) |
| **Bloque 1** | **La Física del Problema** | Slides 2 y 3 | **4 minutos** (01:00 - 05:00) |
| **Bloque 2** | **La Simulación y los Resultados** | Slides 4, 5, 6, 7 y 8 | **10 minutos** (05:00 - 15:00) |
| **Bloque 3** | **El Proceso y Manejo del Agente de IA** | Slides 9, 10, 11 y 12 | **5 minutos** (15:00 - 20:00) |

---

## 📝 Guion Diapositiva por Diapositiva (Qué decir exactamente)

---

### Diapositiva 1: Portada y Estructura (00:00 - 01:00)
> *"Buenas a todos, profesores y compañeros. Mi nombre es Valentina Oundjian y hoy les voy a presentar mi proyecto final: una simulación gravitatoria de un sistema planetario de 3 cuerpos.*  
> *Siguiendo las pautas del curso, la presentación está dividida en tres bloques bien claros:*  
> *• En los **primeros 5 minutos**, vamos a ver la física: qué problema estamos resolviendo y la intuición geométrica de por qué los métodos numéricos pueden fallar.*  
> *• En los **siguientes 10 minutos**, pasamos a la simulación: el código en marcha, cómo está estructurado y cómo validamos científicamente los resultados.*  
> *• Y en los **últimos 5 minutos**, nos enfocamos en lo central de la materia: cómo trabajé con el agente de IA, cómo lo manejé cuando se desvió y qué cosas aprendí a través de él."*

---

### BLOQUE 1: LA FÍSICA (Minutos 01:00 a 05:00)

#### Diapositiva 2: Del Problema de 2 Cuerpos al Caos de 3 Cuerpos (01:00 - 03:00)
> *"Empecemos por la física: Newton resolvió exactamente el problema de dos cuerpos con lápiz y papel. Si tenemos el Sol y un solo planeta, la órbita es una elipse de Kepler fija y cerrada.*  
> *El problema aparece cuando agregamos un tercer cuerpo, por ejemplo, otro planeta. Ahora no sólo la estrella atrae a los planetas, sino que los planetas se atraen gravitatoriamente entre sí. Henri Poincaré demostró a fines del siglo XIX que este sistema ya no tiene una solución analítica cerrada y dio origen a la teoría del caos determinista.*  
> *Para calcular trayectorias de satélites o sistemas planetarios hoy en día, la única opción es simular numéricamente la segunda ley de Newton paso a paso en el tiempo.*  
> *Para programar esto, transformamos la 2ª ley en un **sistema de primer orden acoplado**: la derivada de la posición es la velocidad, y la derivada de la velocidad es la aceleración gravitatoria.*  
> *Un punto físico fundamental: **la estrella no está fija en el origen**. Trasladamos las condiciones iniciales al centro de masa para que el baricentro esté en reposo ($\vec{R}_{\text{cm}} = \vec{0}$) y el momento lineal inicial sea cero ($\vec{P} = \vec{0}$). La estrella se bambolea respetando la 3ª ley de Newton."*

#### Diapositiva 3: La Idea de Fondo: ¿Por qué falla Euler? (03:00 - 05:00)
> *"Para entender la idea física de fondo sin fórmulas pesadas, pensemos en una analogía cotidiana: **manejar un auto en una rotonda cerrada**.*  
> *Para no salirte de la rotonda, tenés que doblar constantemente el volante hacia el centro; esa fuerza hacia adentro es la gravedad.*  
> *El método numérico más elemental es **Euler explícito**: mira la velocidad al inicio del paso y avanza en línea recta:*  
> $$\vec{r}^{n+1} = \vec{r}^n + \vec{v}^n \Delta t$$  
> *Pero en una curva circular, la velocidad instantánea apunta en la **dirección tangente**. Si vas en una curva y te movés en línea recta sobre la tangente... ¡terminás siempre afuera del círculo!*  
> *En cada paso, el planeta queda un poquito más lejos del centro. Ese alejamiento inyecta energía artificial al sistema, como si tuviera un propulsor invisible. Con miles de pasos, esa ganancia se acumula y la órbita se abre en espiral hasta destruir el sistema.*  
> *Frente a esto existen los **integradores simplécticos**, cuyo representante clásico es **Leapfrog** (salto de rana). Leapfrog calcula la velocidad en el punto medio del intervalo: cuando el planeta se va a desplazar, ¡ya dobló el volante hacia la curva! Eso preserva el volumen del espacio de fases (Liouville) y mantiene la energía acotada y las órbitas cerradas por miles de vueltas."*

---

### BLOQUE 2: LA SIMULACIÓN Y LOS RESULTADOS (Minutos 05:00 a 15:00)

#### Diapositiva 4: Demostración Práctica en Vivo (El Código en Marcha) (05:00 - 07:30)
*(Hacer clic en los botones del canvas en vivo directamente en la diapositiva)*  
> *"Pasamos ahora a ver el código en marcha funcionando directamente en la presentación:*  
> *• Acá tenemos corriendo el **sistema completo de 3 cuerpos** de nuestro proyecto: la estrella central en amarillo y los dos planetas en azul y rojo.*  
> *• Miren cómo la estrella no está quieta: se bambolea en el centro alrededor del baricentro respetando la acción y reacción.*  
> *(Clic en '🔴 Euler Explícito'): Miren lo que hace Euler. Con cada revolución, los dos planetas se van más lejos y el error de energía $\delta E(t)$ sube sin parar en el marcador superior (+1%, +2%, +5%...). Las órbitas rojas y azules se van abriendo en espiral.*  
> *(Clic en '🟢 Leapfrog Simpléctico'): Ahora cambio al integrador simpléctico Leapfrog. Miren cómo las órbitas quedan perfectamente estables y cerradas vuelta tras vuelta, y el error de energía se mantiene acotado en 0.000%.*  
> *(Clic en '🎯 Caso Testigo Consigna'): Además, agregué un selector para ver el caso exacto de la consigna oficial ($GM=1, r=1, \Delta t=0.035$).*  
> *Y si el docente quiere ver la ejecución en consola pura, también podemos tirar en la terminal `python main.py` para abrir los gráficos generados en Matplotlib o `python main.py --verificar` para ver pasar las pruebas unitarias."*

#### Diapositiva 5: Cómo está Armado el Código (Arquitectura Modular) (07:00 - 09:00)
> *"Para construir la simulación en Python seguimos una arquitectura modular de funciones breves en NumPy:*  
> *1. `condiciones_iniciales()`: normaliza las unidades ($M=1, G=1, L_0=1$) y aplica la traslación al baricentro.*  
> *2. `aceleraciones()`: calcula la atracción gravitatoria newtoniana por pares. Excluye autointeracciones ($j \neq i$) y detecta separaciones nulas ($r_{ij}=0$) para evitar indeterminaciones.*  
> *3. `paso_euler()`: avanza posición y velocidad usando estrictamente el estado anterior en $t_n$.*  
> *4. `paso_leapfrog()`: implementa el esquema Kick-Drift-Kick (medio impulso, desplazamiento y medio impulso).*  
> *5. `magnitudes()`: evalúa en cada instante la energía mecánica $E=K+U$, el momento lineal $\vec{P}$, el momento angular $L_z$ y la posición del baricentro.*  
> *6. `simular()` y `graficar()`: gestiona el bucle temporal y genera las figuras científicas en Matplotlib garantizando **escala idéntica 1 a 1** (aspect ratio equal) para no deformar visualmente las elipses."*

#### Diapositiva 6: Resultados del Sistema de 3 Cuerpos (09:00 - 10:30)
> *"Acá vemos el resultado de nuestro sistema planetario de 3 cuerpos corriendo durante 10 períodos de referencia:*  
> *Tenemos la estrella central en amarillo y dos planetas de masa 10^-3 a radios 1 y 2.*  
> *Fíjense cómo la estrella bambolea en el centro en respuesta a la gravedad de los planetas.*  
> *Y con Euler observamos claramente cómo las órbitas no se cierran de forma limpia: se abren continuamente y la energía relativa del sistema crece monótonamente hasta alcanzar un +8.7% al final de la corrida."*

#### Diapositiva 7: Validación Física: ¿Cómo sabemos que está bien? (10:30 - 12:30)
> *"¿Cómo nos aseguramos de que esto no tenía bugs de programación? Implementamos tres comprobaciones físicas independientes:*  
> *1. **Prueba a mano independiente:** Antes de armar la simulación grande, calculamos a mano qué pasa si ponemos una masa 1 en el origen y un cuerpo en (1,0) con G=1. La aceleración teórica da exactamente (-1, 0). El código dio exactamente -1.000000.*  
> *2. **Conservación del momento lineal:** Por acción y reacción, las fuerzas internas se cancelan de a pares ($\vec{F}_{ij} = -\vec{F}_{ji}$). En aritmética exacta, la suma de fuerzas es cero. El momento lineal total se conservó con un error máximo de 10^-18, que es el límite de precisión de coma flotante de máquina.*  
> *3. **Período analítico de Kepler:** Para el caso de 2 cuerpos circulares, el tiempo de retorno coincidió con el período analítico $T_{\text{ref}} = 2\pi\sqrt{a^3/GM} \approx 6.2798$."*

#### Diapositiva 8: Caso Testigo de la Consigna y Convergencia $\Delta t$ (12:30 - 15:00)
> *"Como prueba definitiva, fuimos a la consigna oficial del curso, donde los profesores proponían un caso testigo:*  
> *Un planeta circular con $GM=1$, $r=1$ y paso $\Delta t=0.05$ hasta tiempo 30. La pauta decía que con Euler la energía debía subir de -0.5 a -0.23, y con Leapfrog mantenerse en -0.5.*  
> *Corrimos ese experimento exacto en nuestro código y miren los números:*  
> *• Con Euler arrancó en -0.500000 y terminó en **-0.2279** (exactamente el -0.23 de la pauta).*  
> *• Con Leapfrog se mantuvo en **-0.500000** con una variación menor a 3 por 10^-7 (menos de una millonésima).*  
> *Además, hicimos la prueba de convergencia reduciendo el paso a la mitad: el error se redujo con una razón de 1.89 y 1.94, prácticamente 2.0, confirmando experimentalmente que Euler es estrictamente de **primer orden O(dt)**."*

---

### BLOQUE 3: EL PROCESO CON EL AGENTE DE IA (Minutos 15:00 a 20:00)

#### Diapositiva 9: Cómo Manejé al Agente: El Tropiezo con Pygame y la Redirección (15:00 - 16:30)
> *"Ahora entramos a lo central de la materia: **cómo fue el trabajo real con el agente de IA**.*  
> *Acá hubo una experiencia muy concreta de control y aprendizaje. En el primer pedido, el agente generó una aplicación interactiva con Pygame llena de estrellas parpadeantes y presets tipo videojuego. Estaba muy vistoso, pero **no era lo que pedía la facultad**.*  
> *Tuve que intervenir, frenarlo y redirigirlo: le pasé la propuesta académica formal y le exigí las bibliotecas estándar (NumPy, Matplotlib) y una arquitectura modular estricta.*  
> *Aprendí que si uno le hace un pedido vago como 'haceme la simulación', la IA tiende a improvisar y sobrediseñar. Cambié la estrategia hacia **pedidos acotados**: definir la firma de cada función (entradas de arreglos N por 2 y salidas esperadas) y exigirle comprobaciones antes de seguir."*

#### Diapositiva 10: Auditoría Crítica: ¿Cómo Comprobé que no Inventaba? (16:30 - 17:45)
> *"Para no confiar ciegamente en lo que la IA generaba, establecí un protocolo de auditoría:*  
> *1. Le exigí la prueba analítica a mano de aceleración (-1, 0) antes de aceptar la función de fuerzas gravitatorias.*  
> *2. Contrasté las fórmulas de aceleración vectorial y energía orbital con el libro de Fitzpatrick (Introduction to Celestial Mechanics) y los apuntes de la cátedra.*  
> *3. Armamos una suite de pruebas automatizadas con `pytest` que verifica que ninguna modificación rompa los invariantes físicos.*  
> *También resolvimos problemas reales de entorno: al estar usando Python 3.14 en Windows, varias librerías gráficas fallaban por la falta de distutils. Trabajé con el agente para simplificar el stack a librerías estándar puras y asegurar que todo corriera de forma autónoma y reproducible."*

#### Diapositiva 11: El Agente como Tutor: Lo que Entendí que Antes no Entendía (17:45 - 19:00)
> *"El agente no fue sólo un generador de código, sino mi tutor para entender la teoría:*  
> *Le pregunté: '¿Por qué la segunda ley de Newton se descompone en un sistema de primer orden?' Me explicó cómo las computadoras discretizan derivadas y por qué desacoplar posición y velocidad es lo que permite avanzar paso a paso.*  
> *Y sobre todo, le pregunté: '¿Por qué el momento lineal no se desvía pero la energía sí?' Y ahí entendí la diferencia matemática entre la simetría de las fuerzas internas (3ª ley de Newton) y la proyección tangencial de Euler.*  
> *Entendí a fondo qué significa que un método sea **simpléctico**: que conserva la estructura geométrica del espacio de fases. Esto conecta directamente con mi carrera (Astronomía) y el curso de Dinámica Orbital, donde usamos herramientas profesionales como **REBOUND** que se basan en esta misma filosofía."*

#### Diapositiva 12: Conclusiones y Cierre (19:00 - 20:00)
> *"Para cerrar, me quedo con tres conclusiones principales:*  
> *1. Un algoritmo puede estar programado sin ningún bug y aun así violar la física si el método numérico no conserva la geometría del sistema.*  
> *2. Los integradores simplécticos como Leapfrog son indispensables en astronomía porque garantizan estabilidad a largo plazo.*  
> *3. El agente de IA es un multiplicador del aprendizaje siempre que el estudiante mantenga el criterio científico, audite cada resultado y lo guíe con precisión.*  
> *Todo el código, los tests y los gráficos están disponibles en el repositorio. ¡Muchas gracias y quedo abierta a sus preguntas!"*

---

## 🎯 Respuestas Rápidas para las Preguntas de los Profesores

* **Si preguntan: "¿Por qué no usaste Runge-Kutta 4 (RK4)?"**  
  *Respuesta:* *"RK4 es de orden 4 y tiene un error local muy chico, pero tampoco es simpléctico. Para miles de órbitas también presenta deriva de energía. Leapfrog, siendo de segundo orden, es superior a largo plazo porque conserva el espacio de fases."*
* **Si preguntan: "¿Qué fue lo más difícil de manejar del agente?"**  
  *Respuesta:* *"Mantenerlo enfocado en el alcance académico estricto y evitar que agregue código complejo innecesario cuando lo que se buscaban eran funciones científicas limpias y verificables."*
* **Si piden ver los tests en la terminal:**  
  *Ejecutar:* `python main.py --verificar` (tarda 2 segundos y muestra los 6 tests en verde).
