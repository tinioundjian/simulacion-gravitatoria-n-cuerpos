# -*- coding: utf-8 -*-
"""
Validador sintáctico estricto para guion_presentacion.tex
Verifica llaves { }, entornos \\begin{...} \\end{...}, y caracteres no escapados.
"""

import re

def validate_latex(tex_path):
    with open(tex_path, "r", encoding="utf-8") as f:
        content = f.read()

    errors = []
    
    # 1. Check environments begin/end match
    begins = re.findall(r'\\begin\{([a-zA-Z0-9\*]+)\}', content)
    ends = re.findall(r'\\end\{([a-zA-Z0-9\*]+)\}', content)
    
    print(f"Total \\begin: {len(begins)}, Total \\end: {len(ends)}")
    if len(begins) != len(ends):
        errors.append(f"Mismatch in count of begins ({len(begins)}) vs ends ({len(ends)})")
        
    stack = []
    lines = content.splitlines()
    for line_num, line in enumerate(lines, 1):
        # strip comments
        line_clean = re.sub(r'(?<!\\)%.*', '', line)
        
        # find begins and ends in order on this line
        tokens = re.findall(r'\\(begin|end)\{([a-zA-Z0-9\*]+)\}', line_clean)
        for kind, name in tokens:
            if kind == 'begin':
                stack.append((name, line_num))
            elif kind == 'end':
                if not stack:
                    errors.append(f"Line {line_num}: Unexpected \\end{{{name}}} with empty stack")
                else:
                    top_name, top_line = stack.pop()
                    if top_name != name:
                        errors.append(f"Line {line_num}: Mismatched \\end{{{name}}} (expected \\end{{{top_name}}} opened at line {top_line})")
                        
    if stack:
        for name, line_num in stack:
            errors.append(f"Unclosed \\begin{{{name}}} opened at line {line_num}")
            
    # 2. Check braces balance (ignoring escaped \{ and \})
    brace_depth = 0
    for line_num, line in enumerate(lines, 1):
        line_clean = re.sub(r'(?<!\\)%.*', '', line)
        # remove escaped \{ and \}
        line_clean = line_clean.replace(r'\{', '').replace(r'\}', '')
        for char in line_clean:
            if char == '{':
                brace_depth += 1
            elif char == '}':
                brace_depth -= 1
                if brace_depth < 0:
                    errors.append(f"Line {line_num}: Negative brace depth")
                    brace_depth = 0
                    
    if brace_depth != 0:
        errors.append(f"End of file: Unbalanced braces, remaining depth = {brace_depth}")

    # 3. Check for bare unescaped % or _ outside comments / code
    # Check lines
    for line_num, line in enumerate(lines, 1):
        # find raw % that is not \%
        m = re.search(r'(?<!\\)%', line)
        # If there's a comment %, everything before it should not have unescaped _ or &
        before_comment = line[:m.start()] if m else line
        # check unescaped _ outside math
        # math can have _: e.g. $t_0$, but text shouldn't have bare _
        # remove math
        no_math = re.sub(r'\$[^\$]+\$', '', before_comment)
        # check for unescaped _
        bare_underscores = re.findall(r'(?<!\\)_', no_math)
        if bare_underscores:
            errors.append(f"Line {line_num}: Unescaped underscore '_' found in: {no_math.strip()}")

    print("\n--- RESULTADOS DE VALIDACIÓN ---")
    if not errors:
        print("¡VALIDACIÓN 100% EXITOSA! Ningún error de sintaxis, entornos o llaves encontrado.")
    else:
        print(f"Se encontraron {len(errors)} posibles problemas:")
        for e in errors[:10]:
            print("  *", e)

if __name__ == "__main__":
    validate_latex(r"C:\Users\valen\.gemini\antigravity\scratch\nbody_sim\guion_presentacion.tex")
