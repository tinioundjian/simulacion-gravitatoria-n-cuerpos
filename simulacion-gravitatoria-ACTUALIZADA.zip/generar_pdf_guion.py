# -*- coding: utf-8 -*-
"""
Generador automático del Guión Monólogo de 20 minutos en PDF con ReportLab.
Autora: Valentina Oundjian (Facultad de Ciencias, UdelaR)
"""

import re
import os
from reportlab.lib.pagesizes import letter
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.platypus import (
    SimpleDocTemplate,
    Paragraph,
    Spacer,
    Table,
    TableStyle,
    KeepTogether,
    HRFlowable,
)
from reportlab.pdfgen import canvas

class NumberedCanvas(canvas.Canvas):
    def __init__(self, *args, **kwargs):
        super(NumberedCanvas, self).__init__(*args, **kwargs)
        self._saved_page_states = []

    def showPage(self):
        self._saved_page_states.append(dict(self.__dict__))
        self._startPage()

    def save(self):
        num_pages = len(self._saved_page_states)
        for state in self._saved_page_states:
            self.__dict__.update(state)
            self.draw_page_decorations(num_pages)
            canvas.Canvas.showPage(self)
        canvas.Canvas.save(self)

    def draw_page_decorations(self, page_count):
        self.saveState()
        self.setFont("Helvetica", 8)
        self.setFillColor(colors.HexColor("#64748B"))
        
        # Header (en páginas > 1)
        if self._pageNumber > 1:
            self.drawString(40, 755, "Valentina Oundjian — Guión Maestro de Presentación Oral (20 min) — UdelaR")
            self.setStrokeColor(colors.HexColor("#CBD5E1"))
            self.setLineWidth(0.5)
            self.line(40, 750, 572, 750)
            
        # Footer
        self.setStrokeColor(colors.HexColor("#CBD5E1"))
        self.setLineWidth(0.5)
        self.line(40, 40, 572, 40)
        self.drawString(40, 28, "Simulación Gravitatoria 2D — Licenciatura en Astronomía — Computación 2026")
        page_str = f"Página {self._pageNumber} de {page_count}"
        self.drawRightString(572, 28, page_str)
        self.restoreState()

def clean_html(text):
    text = text.replace("&", "&amp;")
    text = text.replace("<", "&lt;").replace(">", "&gt;")
    # Bold
    text = re.sub(r'\*\*([^\*]+)\*\*', r'<b>\1</b>', text)
    # Italics
    text = re.sub(r'\*([^\*]+)\*', r'<i>\1</i>', text)
    # Code
    text = re.sub(r'`([^`]+)`', r'<font face="Courier" color="#1E293B"><b>\1</b></font>', text)
    return text

def build_pdf():
    md_path = r"C:\Users\valen\.gemini\antigravity\scratch\nbody_sim\GUION_MONOLOGO_20MIN.md"
    pdf_path = r"C:\Users\valen\.gemini\antigravity\scratch\nbody_sim\Guion_Presentacion_Valentina_Oundjian.pdf"
    
    with open(md_path, "r", encoding="utf-8") as f:
        md_text = f.read()

    doc = SimpleDocTemplate(
        pdf_path,
        pagesize=letter,
        leftMargin=40,
        rightMargin=40,
        topMargin=48,
        bottomMargin=48
    )

    styles = getSampleStyleSheet()
    
    # Custom Styles
    style_title = ParagraphStyle(
        "DocTitle",
        parent=styles["Normal"],
        fontName="Helvetica-Bold",
        fontSize=20,
        leading=24,
        textColor=colors.HexColor("#1E3A8A"),
        alignment=1,
        spaceAfter=4
    )
    style_subtitle = ParagraphStyle(
        "DocSub",
        parent=styles["Normal"],
        fontName="Helvetica-Bold",
        fontSize=12,
        leading=16,
        textColor=colors.HexColor("#0F766E"),
        alignment=1,
        spaceAfter=4
    )
    style_meta = ParagraphStyle(
        "DocMeta",
        parent=styles["Normal"],
        fontName="Helvetica",
        fontSize=9.5,
        leading=13,
        textColor=colors.HexColor("#475569"),
        alignment=1,
        spaceAfter=12
    )
    style_sec_header = ParagraphStyle(
        "SecHeader",
        parent=styles["Normal"],
        fontName="Helvetica-Bold",
        fontSize=11,
        leading=15,
        textColor=colors.white,
    )
    style_slide_title = ParagraphStyle(
        "SlideTitle",
        parent=styles["Normal"],
        fontName="Helvetica-Bold",
        fontSize=9.5,
        leading=13,
        textColor=colors.HexColor("#1E3A8A"),
    )
    style_cue = ParagraphStyle(
        "CueStyle",
        parent=styles["Normal"],
        fontName="Helvetica-Oblique",
        fontSize=8.5,
        leading=11.5,
        textColor=colors.HexColor("#6D28D9"),
    )
    style_demo = ParagraphStyle(
        "DemoStyle",
        parent=styles["Normal"],
        fontName="Helvetica-Bold",
        fontSize=8.5,
        leading=11.5,
        textColor=colors.HexColor("#065F46"),
    )
    style_speech = ParagraphStyle(
        "SpeechStyle",
        parent=styles["Normal"],
        fontName="Times-Roman",
        fontSize=10,
        leading=14.5,
        textColor=colors.HexColor("#0F172A"),
        spaceAfter=6
    )
    style_machete_q = ParagraphStyle(
        "MacheteQ",
        parent=styles["Normal"],
        fontName="Helvetica-Bold",
        fontSize=10,
        leading=13,
        textColor=colors.HexColor("#1E3A8A"),
        spaceAfter=4
    )
    style_machete_a = ParagraphStyle(
        "MacheteA",
        parent=styles["Normal"],
        fontName="Times-Italic",
        fontSize=9.5,
        leading=13.5,
        textColor=colors.HexColor("#1E293B"),
    )

    story = []
    
    # Title Block
    story.append(Paragraph("GUIÓN MAESTRO DE PRESENTACIÓN ORAL (20 MINUTOS)", style_title))
    story.append(Paragraph("Monólogo Palabra por Palabra — Simulación Gravitatoria de un Sistema Planetario 2D", style_subtitle))
    story.append(Paragraph("<b>Estudiante:</b> Valentina Oundjian &nbsp;|&nbsp; <b>Carrera:</b> Licenciatura en Astronomía (UdelaR) &nbsp;|&nbsp; <b>Curso:</b> Computación 2026", style_meta))
    story.append(HRFlowable(width="100%", thickness=1.5, color=colors.HexColor("#1E3A8A"), spaceBefore=0, spaceAfter=8))
    
    # Roadmap Table
    roadmap_data = [
        [Paragraph("<b>ESTRUCTURA TEMPORAL OFICIAL ACORDADA (5 - 10 - 5)</b>", ParagraphStyle("H", fontName="Helvetica-Bold", fontSize=9, textColor=colors.HexColor("#1E3A8A")))],
        [Paragraph("• <b>00:00 a 05:00 (5 min) — Bloque 1: La Física.</b> De 2 cuerpos a N cuerpos (Poincaré/caos); intuición geométrica de por qué falla Euler y Leapfrog simpléctico.<br/>"
                   "• <b>05:00 a 15:00 (10 min) — Bloque 2: La Simulación en Marcha.</b> Demo interactiva en vivo; arquitectura modular de 6 funciones; prueba analítica a mano (-1, 0); conservación del momento (10<sup>-18</sup>) y convergencia O(Δt).<br/>"
                   "• <b>15:00 a 20:00 (5 min) — Bloque 3: El Proceso con el Agente de IA.</b> Tropiezo inicial con Pygame (videojuego arcade) y redirección a ciencia; auditoría con cuentas a mano; escollo de Python 3.14 (distutils); el agente como tutor conceptual.", 
                   ParagraphStyle("B", fontName="Helvetica", fontSize=8, leading=11, textColor=colors.HexColor("#334155")))]
    ]
    t_road = Table(roadmap_data, colWidths=[532])
    t_road.setStyle(TableStyle([
        ('BACKGROUND', (0,0), (-1,-1), colors.HexColor("#F8FAFC")),
        ('BOX', (0,0), (-1,-1), 1, colors.HexColor("#CBD5E1")),
        ('LEFTPADDING', (0,0), (-1,-1), 8),
        ('RIGHTPADDING', (0,0), (-1,-1), 8),
        ('TOPPADDING', (0,0), (-1,-1), 5),
        ('BOTTOMPADDING', (0,0), (-1,-1), 6),
    ]))
    story.append(t_road)
    story.append(Spacer(1, 10))

    # Split into sections
    sections_raw = re.split(r"(### [^\n]+)", md_text)
    
    # Process sections 1 to 11
    for b_idx in range(11):
        raw_idx = 1 + b_idx * 2
        title_raw = sections_raw[raw_idx].strip()
        body_raw = sections_raw[raw_idx + 1].strip()
        
        # Clean title
        clean_title = title_raw.replace("###", "").replace("⏱️", "").strip()
        
        # Section Header Banner
        header_table = Table([[Paragraph(f"<b>{clean_title}</b>", style_sec_header)]], colWidths=[532])
        header_table.setStyle(TableStyle([
            ('BACKGROUND', (0,0), (-1,-1), colors.HexColor("#1E3A8A")),
            ('LEFTPADDING', (0,0), (-1,-1), 8),
            ('RIGHTPADDING', (0,0), (-1,-1), 8),
            ('TOPPADDING', (0,0), (-1,-1), 4),
            ('BOTTOMPADDING', (0,0), (-1,-1), 4),
        ]))
        
        story.append(KeepTogether([Spacer(1, 6), header_table, Spacer(1, 4)]))
        
        # Process body
        lines = []
        for l in body_raw.splitlines():
            l_str = l.strip()
            if l_str.startswith('>'):
                l_str = l_str[1:].strip()
            lines.append(l_str)
            
        full_content = "\n".join(lines)
        paragraphs = [p.strip() for p in re.split(r'\n\s*\n', full_content) if p.strip()]
        
        for p in paragraphs:
            # 1. Posture / attitude: *(...)*
            if p.startswith('*(') and p.endswith(')*'):
                clean_p = clean_html(p[2:-2])
                t_box = Table([[Paragraph(f"<b>[POSTURA / ACTITUD]</b> {clean_p}", style_cue)]], colWidths=[532])
                t_box.setStyle(TableStyle([
                    ('BACKGROUND', (0,0), (-1,-1), colors.HexColor("#F5F3FF")),
                    ('BOX', (0,0), (-1,-1), 0.5, colors.HexColor("#DDD6FE")),
                    ('LEFTPADDING', (0,0), (-1,-1), 6),
                    ('RIGHTPADDING', (0,0), (-1,-1), 6),
                    ('TOPPADDING', (0,0), (-1,-1), 3),
                    ('BOTTOMPADDING', (0,0), (-1,-1), 3),
                ]))
                story.append(t_box)
                story.append(Spacer(1, 3))
                
            # 2. Slide transition
            elif p.startswith('`[SLIDE') or p.startswith('`[PASAR A SLIDE'):
                clean_p = clean_html(p.replace('`[', '').replace(']`', ''))
                t_slide = Table([[Paragraph(f"<b>PROYECTAR EN PANTALLA:</b> {clean_p}", style_slide_title)]], colWidths=[532])
                t_slide.setStyle(TableStyle([
                    ('BACKGROUND', (0,0), (-1,-1), colors.HexColor("#EFF6FF")),
                    ('BOX', (0,0), (-1,-1), 0.8, colors.HexColor("#93C5FD")),
                    ('LEFTPADDING', (0,0), (-1,-1), 8),
                    ('RIGHTPADDING', (0,0), (-1,-1), 8),
                    ('TOPPADDING', (0,0), (-1,-1), 4),
                    ('BOTTOMPADDING', (0,0), (-1,-1), 4),
                ]))
                story.append(t_slide)
                story.append(Spacer(1, 4))
                
            # 3. Demo live action
            elif p.startswith("`[Hacer clic"):
                clean_p = clean_html(p.replace('`[', '').replace(']`', ''))
                t_demo = Table([[Paragraph(f"<b>[DEMO EN VIVO]</b> {clean_p}", style_demo)]], colWidths=[532])
                t_demo.setStyle(TableStyle([
                    ('BACKGROUND', (0,0), (-1,-1), colors.HexColor("#ECFDF5")),
                    ('BOX', (0,0), (-1,-1), 0.8, colors.HexColor("#A7F3D0")),
                    ('LEFTPADDING', (0,0), (-1,-1), 6),
                    ('RIGHTPADDING', (0,0), (-1,-1), 6),
                    ('TOPPADDING', (0,0), (-1,-1), 3),
                    ('BOTTOMPADDING', (0,0), (-1,-1), 3),
                ]))
                story.append(t_demo)
                story.append(Spacer(1, 3))
                
            # 4. Stage cue / gesture
            elif (p.startswith('`[Pausa') or p.startswith('`[Señalar') or 
                  p.startswith('`[Sonreír') or p.startswith('`[Hacer un gesto')):
                clean_p = clean_html(p.replace('`[', '').replace(']`', ''))
                t_cue = Table([[Paragraph(f"<b>[ACCIÓN / PAUSA]</b> {clean_p}", style_cue)]], colWidths=[532])
                t_cue.setStyle(TableStyle([
                    ('BACKGROUND', (0,0), (-1,-1), colors.HexColor("#F5F3FF")),
                    ('BOX', (0,0), (-1,-1), 0.5, colors.HexColor("#DDD6FE")),
                    ('LEFTPADDING', (0,0), (-1,-1), 6),
                    ('RIGHTPADDING', (0,0), (-1,-1), 6),
                    ('TOPPADDING', (0,0), (-1,-1), 3),
                    ('BOTTOMPADDING', (0,0), (-1,-1), 3),
                ]))
                story.append(t_cue)
                story.append(Spacer(1, 3))
                
            # 5. Spoken speech
            else:
                clean_p = p.strip()
                if clean_p.startswith('"') and clean_p.endswith('"'):
                    clean_p = clean_p[1:-1].strip()
                elif clean_p.startswith('"'):
                    clean_p = clean_p[1:].strip()
                elif clean_p.endswith('"'):
                    clean_p = clean_p[:-1].strip()
                clean_p = clean_html(clean_p)
                
                # Speech paragraph with left bar
                t_speech = Table([[Paragraph(clean_p, style_speech)]], colWidths=[532])
                t_speech.setStyle(TableStyle([
                    ('LINELEFT', (0,0), (0,0), 2.5, colors.HexColor("#94A3B8")),
                    ('LEFTPADDING', (0,0), (-1,-1), 10),
                    ('RIGHTPADDING', (0,0), (-1,-1), 4),
                    ('TOPPADDING', (0,0), (-1,-1), 2),
                    ('BOTTOMPADDING', (0,0), (-1,-1), 3),
                ]))
                story.append(t_speech)
                story.append(Spacer(1, 2))

    # Machete final
    story.append(Spacer(1, 10))
    story.append(HRFlowable(width="100%", thickness=1.5, color=colors.HexColor("#1E3A8A"), spaceBefore=4, spaceAfter=8))
    story.append(Paragraph("<b>MACHETE DE RESPUESTAS ANTE PREGUNTAS DEL TRIBUNAL</b>", ParagraphStyle("MachTitle", fontName="Helvetica-Bold", fontSize=12, textColor=colors.HexColor("#1E3A8A"), alignment=1)))
    story.append(Spacer(1, 6))
    
    machete_items = [
        ("Pregunta 1: ¿Por qué no usaste Runge-Kutta 4 (RK4) que es de orden 4?",
         "RK4 tiene un error local muy chico de orden 4, pero tampoco es simpléctico. Para misiones de pocos días funciona muy bien, pero a lo largo de miles de órbitas también sufre de deriva secular de energía. Leapfrog, aunque sea de segundo orden, es superior a largo plazo porque conserva el volumen del espacio de fases (teorema de Liouville) y es estrictamente reversible en el tiempo."),
        ("Pregunta 2: ¿Por qué no usaste el algoritmo de Barnes-Hut?",
         "Porque para 3 cuerpos, calcular todos los pares cuesta únicamente 3 operaciones (N(N-1)/2). Barnes-Hut utiliza un árbol espacial para agrupar partículas lejanas y se vuelve necesario recién cuando simulamos galaxias o cúmulos con miles de estrellas, donde pasar de O(N²) a O(N log N) es indispensable para que la computadora no se cuelgue."),
        ("Demostración de tests en vivo en la terminal:",
         "Escribir en la terminal: <b>python main.py --verificar</b>.<br/>Las 6 pruebas unitarias correrán con pytest demostrando la aceleración analítica (-1,0), conservación de momento (10<sup>-18</sup>), orden de convergencia O(Δt) y manejo de colisiones en menos de 2 segundos.")
    ]
    
    for q, a in machete_items:
        m_data = [
            [Paragraph(f"<b>{q}</b>", style_machete_q)],
            [Paragraph(f"<i>«{a}»</i>", style_machete_a)]
        ]
        t_m = Table(m_data, colWidths=[532])
        t_m.setStyle(TableStyle([
            ('BACKGROUND', (0,0), (-1,-1), colors.HexColor("#F8FAFC")),
            ('BOX', (0,0), (-1,-1), 1, colors.HexColor("#1E3A8A")),
            ('LEFTPADDING', (0,0), (-1,-1), 8),
            ('RIGHTPADDING', (0,0), (-1,-1), 8),
            ('TOPPADDING', (0,0), (-1,-1), 5),
            ('BOTTOMPADDING', (0,0), (-1,-1), 5),
        ]))
        story.append(KeepTogether([t_m, Spacer(1, 6)]))

    doc.build(story, canvasmaker=NumberedCanvas)
    print(f"PDF successfully generated: {pdf_path}")

if __name__ == "__main__":
    build_pdf()
