# 🎬 GUION MAESTRO PALABRA POR PALABRA (20 MINUTOS EXACTOS)

---

### ⏱️ MINUTO 00:00 a 01:00 — APERTURA Y HOJA DE RUTA
*(Estar parada tranquila, mirar a los profesores y a los compañeros, sonreír y respirar hondo)*

`[SLIDE 1: Portada en pantalla]`

> "Buenas tardes a todos, profesores y compañeros. Mi nombre es Valentina Oundjian, soy estudiante de la Licenciatura en Astronomía y hoy les vengo a presentar mi proyecto final para el curso de Computación: una simulación gravitatoria de un sistema planetario de tres cuerpos.
>
> `[Pausa de 2 segundos]`
>
> Para que la presentación sea clara, dinámica y no nos perdamos en detalles aislados, estructuré estos 20 minutos siguiendo la sugerencia de la cátedra en tres grandes bloques que cuentan una historia completa:
>
> En los primeros cinco minutos, nos vamos a meter en la física: cuál es el problema matemático que queremos resolver, qué pasa cuando pasamos de dos a tres cuerpos y la intuición geométrica de por qué los métodos numéricos en una computadora pueden fallar.
>
> En los siguientes diez minutos, vamos a ver la simulación en marcha: el programa funcionando en vivo en pantalla, cómo estructuré el código en Python con NumPy y las pruebas científicas que demuestran que los resultados son correctos y no tienen errores de programación.
>
> Y en los últimos cinco minutos, vamos a profundizar en lo que considero el corazón pedagógico de este curso: cómo fue mi trabajo real con el agente de inteligencia artificial. Les voy a contar cómo lo manejé, el momento exacto en el que tuve que frenarle el carro porque se estaba desviando, cómo lo audité con cuentas hechas a mano para no creerle ciegamente, y qué conceptos teóricos aprendí gracias a él.
>
> `[Pausa de 2 segundos]`
>
> Empecemos entonces por la física del problema."

---

### ⏱️ MINUTO 01:00 a 03:00 — BLOQUE 1: LA FÍSICA (De 2 cuerpos a N cuerpos)

`[PASAR A SLIDE 2: Del problema de 2 cuerpos al caos de 3 cuerpos]`

> "Para entender qué estamos haciendo acá, tenemos que viajar un momento a la historia de la mecánica celeste.
>
> `[Señalar la pantalla]`
>
> En el siglo diecisiete, Isaac Newton resolvió con lápiz y papel el problema de dos cuerpos. Si en el universo tenemos únicamente al Sol y a un planeta, la física es limpia y predecible: la fuerza de gravedad genera una órbita cerrada, una elipse perfecta que cumple las leyes de Kepler y que podemos calcular analíticamente hasta el fin de los tiempos.
>
> Pero en la astronomía real, los sistemas planetarios nunca están formados por dos cuerpos solos. ¿Qué pasa cuando agregamos un tercer cuerpo, por ejemplo, un segundo planeta?
>
> Ahí la situación cambia radicalmente. Ahora la estrella atrae al planeta uno y al planeta dos, pero al mismo tiempo los dos planetas se atraen gravitatoriamente entre sí con una fuerza proporcional a sus masas e inversamente proporcional al cuadrado de la distancia que los separa.
>
> A fines del siglo diecinueve, el matemático Henri Poincaré intentó resolver este sistema de tres cuerpos buscando una fórmula analítica y descubrió algo revolucionario: demostró matemáticamente que no existe una solución general cerrada en términos de funciones algebraicas. Con ese descubrimiento nació el estudio moderno del caos determinista. El sistema sigue estrictamente las leyes de Newton, pero las trayectorias ya no se pueden predecir con una sola fórmula mágica.
>
> `[Pausa de 2 segundos]`
>
> Entonces, ¿cómo calculamos hoy en día la trayectoria de una sonda que viaja a Marte, o la estabilidad de un sistema de exoplanetas descubierto por un telescopio?
>
> La única forma que tenemos en la ciencia moderna es simular la ley de gravitación paso a paso en el tiempo utilizando una computadora.
>
> Para que una computadora pueda resolver esto, tomamos la segunda ley de Newton —fuerza igual a masa por aceleración— y la reescribimos como un sistema de ecuaciones diferenciales acopladas de primer orden: la derivada de la posición respecto al tiempo es la velocidad, y la derivada de la velocidad respecto al tiempo es la aceleración gravitatoria que ejercen todos los demás cuerpos.
>
> Y acá entra un detalle físico fundamental de mi modelo que quiero remarcar: en mi simulación, la estrella no está clavada artificialmente en el origen. Un error muy común es dejar la estrella fija, pero eso viola la tercera ley de Newton: si los planetas son atraídos por la estrella, la estrella también tiene que sentir la atracción de los planetas.
>
> Por eso, calculamos la posición y la velocidad del centro de masa —el baricentro del sistema— y trasladamos todo el sistema a ese marco de referencia. De esa manera, el centro de masa arranca en reposo absoluto en el origen, el momento lineal inicial es exactamente cero, y la estrella tiene permitido bambolearse libremente respondiendo a los planetas.
>
> Y esto nos lleva a la gran pregunta física del proyecto: cuando usamos una computadora para calcular órbitas paso a paso... ¿el método numérico respeta las leyes de conservación de la naturaleza o inventa comportamientos artificiales?"

---

### ⏱️ MINUTO 03:00 a 05:00 — BLOQUE 1: LA FÍSICA (La Intuición Geométrica)

`[PASAR A SLIDE 3: La intuición geométrica: ¿Por qué falla Euler?]`

> "Para responder a esa pregunta sin ahogarnos en ecuaciones diferenciales pesadas, les quiero proponer una analogía muy visual y cotidiana: imagínense que van manejando un auto en una rotonda cerrada.
>
> `[Hacer un gesto circular con la mano]`
>
> Para mantenerse adentro de la rotonda y no chocar contra el cordón, ustedes tienen que doblar constantemente el volante hacia el centro. Esa fuerza hacia adentro en nuestro sistema planetario es la fuerza de gravedad de la estrella.
>
> Ahora bien: ¿cómo avanza en el tiempo el método numérico más elemental y conocido de todos, que es el método de Euler explícito?
>
> Euler mira la velocidad instantánea que tiene el planeta al principio del intervalo y dice: 'bueno, durante los próximos delta t segundos, supongamos que el planeta se mueve en línea recta siguiendo esa velocidad':
>
> posición nueva igual a posición vieja más velocidad por delta t.
>
> Pero piensen un segundo en la geometría de un círculo: en una curva, la velocidad instantánea apunta exactamente en la dirección tangente. Si ustedes van doblando en una rotonda y de repente clavan el volante recto y avanzan en línea recta sobre la tangente... ¿qué pasa?
>
> `[Pausa de 1 segundo]`
>
> Terminan inevitablemente afuera del círculo.
>
> En cada pasito de tiempo que da la computadora, por más chiquito que sea el delta t, el planeta termina a una distancia un poquitito mayor de la estrella que la que le correspondía por la física real. Al quedar más lejos, el método numérico le acaba de regalar energía potencial al planeta. Es como si el planeta tuviera un motor invisible en la cola empujándolo hacia afuera en cada paso.
>
> Si ustedes dan diez pasos, no pasa nada grave. Pero si la computadora calcula diez mil pasos para simular varias vueltas, esa ganancia espuria de energía se acumula paso a paso, la energía del sistema crece sin parar y la órbita se abre en una espiral destructiva hasta que los planetas salen eyectados al espacio interestelar.
>
> `[Pausa de 2 segundos]`
>
> Frente a este fracaso evidente de Euler, la mecánica celeste desarrolló una familia especial de algoritmos llamados integradores simplécticos, cuyo máximo exponente es el método de Leapfrog, o salto de rana.
>
> ¿Cuál es el secreto de Leapfrog? Leapfrog no actualiza la posición y la velocidad al mismo tiempo con los valores viejos. Hace un esquema escalonado: primero calcula un medio paso de velocidad con la aceleración actual.
>
> Cuando el planeta efectivamente se va a desplazar en el espacio, la velocidad que utiliza ya dobló hacia la curva. Es como si en el auto dobláramos el volante en el punto medio del paso. Al hacer esto, la trayectoria se compensa casi a la perfección.
>
> Matemáticamente, Leapfrog conserva el volumen del espacio de fases —lo que en física se conoce como el teorema de Liouville— y es estrictamente reversible en el tiempo. La energía del sistema no se escapa: oscila muy suavemente alrededor del valor real pero queda acotada durante miles de años.
>
> Pero en vez de que yo se los cuente en teoría, pasemos al segundo bloque y veámoslo funcionar directamente con el código en marcha."

---

### ⏱️ MINUTO 05:00 a 08:00 — BLOQUE 2: LA SIMULACIÓN EN VIVO (El Código en Marcha)

`[PASAR A SLIDE 4: Demostración Práctica en Vivo]`

> "Acá en pantalla estamos viendo la simulación corriendo en tiempo real, ejecutando exactamente la física de nuestro código.
>
> `[Señalar el canvas en la diapositiva]`
>
> Lo que están viendo en este momento es nuestro sistema planetario de tres cuerpos completo:
> En el centro, en color dorado brillante, tenemos a la estrella central, con una masa igual a uno.
> A distancia uno, en color azul celeste, tenemos al planeta interior, con una masa de una milésima de la masa estelar.
> Y a distancia dos, en color rojo, tenemos al planeta exterior, también con una masa de una milésima.
>
> Fíjense en un detalle muy lindo: si miran con atención a la estrella dorada en el centro, van a notar que no está quieta. Se bambolea describiendo una pequeña órbita alrededor de la cruz amarilla tenue del centro de masa, respondiendo a la atracción combinada de ambos planetas.
>
> `[Pausa de 2 segundos]`
>
> Ahora miren lo que pasa con la física del método numérico:
>
> `[Hacer clic en el botón rojo '🔴 Euler Explícito']`
>
> En este momento el sistema está integrando con Euler explícito, con un paso de tiempo delta t de dos milésimas y media.
>
> Miren lo que le pasa a las trazas orbitales: vuelta tras vuelta, el planeta azul y el planeta rojo se van alejando de la estrella. Las órbitas no se cierran; se van abriendo progresivamente en una espiral evidente.
>
> Y miren el marcador que tenemos arriba en el panel de control: el error relativo de energía delta E, que mide cuánto se desvió la energía respecto al valor inicial, empezó en cero por ciento y ahora ya va subiendo: más uno por ciento, más dos por ciento, más cuatro por ciento... el integrador está inflando el sistema con energía que no existe en la realidad.
>
> `[Pausa de 2 segundos]`
>
> Ahora voy a cambiar de integrador en vivo:
>
> `[Hacer clic en el botón verde '🟢 Leapfrog Simpléctico']`
>
> Miren la diferencia radical. Estamos usando exactamente las mismas masas, exactamente las mismas posiciones iniciales y exactamente el mismo paso de tiempo.
>
> Y sin embargo, las órbitas del planeta azul y del planeta rojo se superponen de manera casi perfecta sobre sí mismas en cada vuelta. Miren el panel superior: el error relativo de energía se mantiene congelado en cero punto cero cero cero por ciento, oscilando apenas en el sexto o séptimo decimal.
>
> `[Hacer clic en el botón '🎯 Caso Testigo Consigna']`
>
> Y agregué además este selector para mostrarles el caso testigo exacto que ustedes, los docentes, nos plantearon en la consigna de la materia: un solo planeta circular con GM igual a uno, radio uno y paso de tiempo cero punto cero treinta y cinco.
>
> Con Euler vemos cómo la energía salta de menos cero punto cinco hacia menos cero punto veintitrés mientras el planeta se abre en espiral roja, mientras que con Leapfrog la curva verde permanece perfectamente cerrada y la energía se clava en menos cero punto cinco con una variación menor a una millonésima.
>
> Esto nos da una demostración visual contundente: el escape de los planetas no era un fenómeno astronómico real, sino una patología matemática del método de Euler."

---

### ⏱️ MINUTO 08:00 a 10:30 — BLOQUE 2: CÓMO ESTÁ ARMADO EL CÓDIGO (Arquitectura Modular)

`[PASAR A SLIDE 5: Cómo está armado el código (Arquitectura modular)]`

> "Ahora que vimos el resultado visual, quiero mostrarles cómo está estructurado el código por dentro en Python, en el archivo `simulacion_planetaria.py`.
>
> Siguiendo las buenas prácticas que me propuse en el marco teórico, el código no es un script largo y desordenado, sino que está dividido en seis funciones modulares bien concretas, utilizando NumPy para todas las operaciones numéricas:
>
> `[Señalar la primera tarjeta en pantalla]`
>
> La primera función es `condiciones_iniciales()`. Esta función toma las masas en unidades normalizadas —masa de la estrella igual a uno, constante gravitatoria igual a uno y distancia de la Tierra igual a uno— y coloca a los planetas en el eje X con sus velocidades keplerianas teóricas perpendiculares.
> Pero lo más importante que hace es calcular el centro de masa y la velocidad del centro de masa, y restárselos a cada cuerpo. Por eso, si miran las posiciones en el código, van a ver que la estrella no arranca en cero cero, sino en menos cero punto cero cero veintinueve, y tiene una pequeña velocidad negativa hacia el eje Y para compensar a los planetas y hacer que el momento total inicial sea exactamente cero.
>
> `[Señalar la segunda tarjeta]`
>
> La segunda función es `aceleraciones()`. Esta función recibe la matriz de posiciones de dimensión tres por dos y las masas, y calcula la fuerza neta sobre cada cuerpo sumando la atracción de todos los demás según la ley de gravitación de Newton.
> En el código incluí dos protecciones fundamentales: primero, una condición que dice 'si i es igual a j, continuar', para que un planeta no calcule la fuerza de atracción sobre sí mismo. Y segundo, una verificación que detecta si la distancia euclídea entre dos cuerpos llega a ser cero, en cuyo caso lanza una excepción de división por cero antes de hacer la cuenta, evitando que el programa se cuelgue con un valor indefinido si hubiera una colisión.
>
> `[Señalar las tarjetas de paso_euler y paso_leapfrog]`
>
> La tercera y cuarta función son los motores de integración: `paso_euler()` y `paso_leapfrog()`. Están separadas de la física de fuerzas. `paso_euler` actualiza posiciones y velocidades usando estrictamente el estado anterior en el tiempo t sub n. Y `paso_leapfrog` implementa el algoritmo Kick-Drift-Kick: da medio impulso de velocidad, desplaza la posición completa con esa velocidad media, recalcula las aceleraciones gravitatorias con la función anterior en la nueva posición, y completa el otro medio impulso de velocidad.
>
> `[Señalar magnitudes y simular]`
>
> La quinta función es `magnitudes()`, que calcula en cada instante los grandes invariantes físicos: la energía cinética, la energía potencial gravitatoria sumando cada par de cuerpos una sola vez, el momento lineal total y el momento angular total en el eje Z.
>
> Y finalmente, la función `simular()` corre el bucle temporal durante diez mil pasos, guarda el historial en arreglos de NumPy preasignados en memoria para que sea ultra rápido, y la función `graficar()` dibuja las figuras utilizando Matplotlib."

---

### ⏱️ MINUTO 10:30 a 12:30 — BLOQUE 2: RESULTADOS Y ESCALA 1 A 1

`[PASAR A SLIDE 6: Resultados del Sistema de 3 Cuerpos]`

> "Acá en la diapositiva seis estamos viendo las figuras científicas que genera el programa en Matplotlib tras simular diez períodos de referencia completos, lo que equivale a diez mil pasos de tiempo.
>
> `[Señalar el gráfico de trayectorias]`
>
> Un detalle técnico crucial que le exigí al código de graficación es la línea:
> `ax.set_aspect('equal')`.
>
> ¿Por qué es tan importante esto? Porque si uno no fuerza la escala idéntica en ambos ejes, Matplotlib estira o achata la ventana para que ocupe toda la pantalla, y una órbita circular se vería deformada como una elipse achatada. Al fijar escala uno a uno, nos aseguramos de que lo que vemos en el gráfico sea la verdadera geometría espacial del sistema.
>
> Y acá vemos con total nitidez el resultado cuantitativo: con Euler, al cabo de diez vueltas, el planeta interior se abrió significativamente hacia afuera, el planeta exterior también se alejó, y la energía mecánica total del sistema creció un ocho punto siete por ciento.
>
> Este ocho punto siete por ciento no es una pequeña fluctuación: es una ganancia sistemática y acumulativa que confirma experimentalmente la deriva secular de Euler."

---

### ⏱️ MINUTO 12:30 a 15:00 — BLOQUE 2: CÓMO SABEMOS QUE ESTÁ BIEN (Validación)

`[PASAR A SLIDE 7: Validación física: ¿Cómo sabemos que el código está bien?]`

> "Llegados a este punto, cualquier persona de ciencias tiene que hacerse una pregunta fundamental:
> ¿Cómo sabemos que estos resultados están bien? ¿Cómo sabemos que la apertura de la órbita se debe a la teoría numérica y no a que yo me equivoqué al tipear un signo más o un signo menos en el código?
>
> `[Pausa de 2 segundos]`
>
> Para responder a esto, diseñamos un protocolo de validación con tres pruebas independientes:
>
> La primera fue una **prueba analítica a mano**. Antes de armar la simulación de tres cuerpos, me senté con lápiz y papel y calculé un caso ultra simple: si ponemos una masa fuente de valor uno en el origen cero cero, y un cuerpo de prueba en la coordenada uno cero, con la constante G igual a uno... ¿cuánto tiene que dar la aceleración del segundo cuerpo?
> La distancia es uno, la fuerza apunta hacia la izquierda sobre el eje X, por lo que la aceleración teórica tiene que ser exactamente menos uno en X y cero en Y: el vector menos uno, cero.
>
> Corrimos la función `aceleraciones()` en Python para esa configuración y el resultado que arrojó fue exactamente menos uno punto cero cero cero cero cero en X y cero en Y. Esta prueba comprobó de forma irrefutable que el signo de atracción, la dirección vectorial y las distancias estaban perfectamente programados.
>
> `[Señalar la segunda tarjeta]`
>
> La segunda prueba fue la **conservación exacta del momento lineal**.
> Por la tercera ley de Newton, toda fuerza que el cuerpo uno le hace al cuerpo dos es igual y opuesta a la que el cuerpo dos le hace al cuerpo uno. Si el código suma bien los pares, las fuerzas internas se cancelan exactamente. En aritmética matemática exacta, la derivada del momento lineal total tiene que ser idénticamente cero.
>
> Medimos el momento lineal a lo largo de los diez mil pasos de la simulación, y la variación máxima observada fue del orden de diez a la menos dieciocho. Diez a la menos dieciocho es el límite de precisión de redondeo de los números de coma flotante de doble precisión de sesenta y cuatro bits del procesador. El momento lineal se conservó de forma perfecta.
>
> `[PASAR A SLIDE 8: Caso testigo de la consigna y convergencia dt]`
>
> Y la tercera prueba fue el análisis de **convergencia al reducir el paso temporal**.
> Corrimos la simulación con tres pasos distintos: delta t, delta t sobre dos, y delta t sobre cuatro.
> Al medir el error global en la posición tras una vuelta completa, descubrimos que al dividir el paso a la mitad, el error se redujo con una razón de uno punto ochenta y nueve y uno punto noventa y cuatro, prácticamente dos punto cero.
> Esto demostró experimentalmente que el método de Euler en nuestro código es estrictamente de **primer orden O de delta t**: para duplicar la exactitud, hay que duplicar la cantidad de cálculos.
>
> Todo esto está automatizado en el archivo `pruebas_verificacion.py` mediante la librería `pytest`, con seis pruebas unitarias que pasan todas en verde en menos de dos segundos si uno ejecuta en la terminal `python main.py --verificar`."

---

### ⏱️ MINUTO 15:00 a 16:30 — BLOQUE 3: EL PROCESO CON EL AGENTE (El Tropiezo con Pygame)

`[PASAR A SLIDE 9: Cómo manejé al Agente: El tropiezo con Pygame y la redirección]`

> "Ahora entramos a la tercera parte de la presentación y a lo que considero el objetivo central de este curso: **cómo fue el proceso real de trabajo con el agente de inteligencia artificial**.
>
> En mi caso utilicé el agente de Antigravity, basado en el modelo Gemini.
>
> Y les quiero contar una experiencia muy real y honesta que tuve al principio:
> En mi primera interacción con el agente, cometí el error típico de principiante: le pedí la simulación 'todo de una vez' con una frase vaga. Le dije algo así como: 'hola, ayudame a hacer una simulación orbital de N cuerpos'.
>
> ¿Y qué hizo el agente?
> El agente sobreactuó, sobrediseñó, y me escribió un programa interactivo gigantesco en la librería Pygame, con navecitas espaciales, estrellas parpadeantes de colores en el fondo, menús con música y controles de teclado estilo videojuego arcade.
>
> `[Sonreír]`
>
> Estaba visualmente increíble, pero **no tenía absolutamente nada que ver con lo que me pedía la facultad**. No había cálculo de magnitudes conservadas, no había escala uno a uno, no había análisis de convergencia y las funciones estaban todas mezcladas adentro de un bucle gráfico imposible de auditar.
>
> En ese momento me di cuenta de algo fundamental: si uno no sabe lo que quiere, la IA te lleva para cualquier lado.
>
> Así que tomé el control del proceso: le frené el carro, le pasé el documento en PDF con mi propuesta formal aprobada por los docentes y le dije:
> 'No, esto no es un videojuego. Necesitamos computación científica estricta: NumPy para matrices vectorizadas, Matplotlib para gráficos con aspecto cuadrado, funciones modulares independientes y pruebas unitarias con pytest'.
>
> A partir de ese tropiezo cambié radicalmente mi forma de interactuar con el agente: dejé de pedirle cosas grandes y pasé a trabajar **en pasos chicos y modulares**."

---

### ⏱️ MINUTO 16:30 a 18:00 — BLOQUE 3: EL PROCESO CON EL AGENTE (Auditoría y Problemas Técnicos)

`[PASAR A SLIDE 10: Auditoría crítica: ¿Cómo comprobé que no inventaba?]`

> "Aprendí que para que un agente de IA sea útil en ciencia, uno tiene que darle especificaciones de ingeniería muy precisas.
>
> En vez de decirle 'calculá la gravedad', le pedía:
> 'Escribí una función llamada `aceleraciones` que reciba un arreglo de posiciones de tamaño N por dos y un arreglo de masas de tamaño N; que verifique si la distancia entre dos cuerpos es cero para lanzar una excepción de colisión, y que devuelva la aceleración gravitatoria sumando los pares distintos de i'.
> Con ese nivel de detalle técnico, el código que generaba era impecable, limpio y directo.
>
> `[Pausa de 1 segundo]`
>
> Pero además establecí un principio de trabajo: **nunca aceptar una función del agente sin antes haberla auditado con una prueba independiente**.
>
> Por eso diseñé la prueba a mano de la masa en cero cero y el cuerpo en uno cero. Antes de dejar que el agente armara el bucle de integración, le hice correr esa prueba específica. Si la función no me devolvía exactamente el vector menos uno cero que yo había calculado en papel, no la aceptaba.
>
> También tuvimos que resolver problemas técnicos reales de entorno:
> En mi computadora tengo instalado Python 3.14, que es una versión muy reciente en la que se eliminó por completo el módulo antiguo `distutils`. Cuando el agente intentaba instalar ciertas librerías gráficas complejas en Windows, el sistema fallaba porque no encontraba el compilador de C.
>
> Trabajando en equipo con el agente, diagnosticamos el error y decidimos simplificar el stack tecnológico a librerías estándar puras que no requirieran compiladores externos. Esa decisión técnica hizo que el proyecto sea hoy cien por ciento reproducible y portátil en cualquier máquina sin configuraciones raras."

---

### ⏱️ MINUTO 18:00 a 19:30 — BLOQUE 3: EL AGENTE COMO TUTOR CONCEPTUAL

`[PASAR A SLIDE 11: El Agente como tutor: Lo que entendí que antes no entendía]`

> "Pero el rol más valioso del agente no fue escribir código, sino actuar como mi **tutor conceptual interactivo** para entender la teoría física y matemática.
>
> Por ejemplo, cuando me encontré con las ecuaciones diferenciales, le pregunté:
> '¿Por qué la segunda ley de Newton se reescribe como un sistema de primer orden?'
> El agente me explicó con mucha claridad que las computadoras no saben calcular derivadas segundas de golpe; necesitan discretizar el tiempo. Al separar la posición y la velocidad en dos derivadas simples de primer orden acopladas, la computadora sólo necesita saber el estado presente para calcular el estado futuro paso a paso.
>
> Y la pregunta más importante que le hice fue:
> '¿Por qué con el método de Euler el momento lineal se conserva con un error de diez a la menos dieciocho, pero la energía se desvía un ocho por ciento?'
>
> Y ahí terminé de entender la física del problema: el momento lineal se conserva porque las fuerzas internas newtonianas son exactamente simétricas por acción y reacción, independientemente del método de integración; mientras que la energía depende de la curvatura de la trayectoria, y la proyección recta por la tangente de Euler destruye la geometría del sistema.
>
> Para estar completamente segura de que el agente no estaba alucinando o inventando explicaciones teóricas, contrasté cada una de sus afirmaciones con el libro de referencia de mecánica celeste de Richard Fitzpatrick y con la biblioteca profesional REBOUND, que utilizamos en mi carrera en la materia Dinámica Orbital.
>
> ¿Qué entiendo hoy que antes de empezar este proyecto no entendía?
> Hoy entiendo a fondo qué significa en matemática que un integrador sea simpléctico: entendí que no es un truco de magia, sino que preserva la estructura geométrica del espacio de fases. Y entendí cómo herramientas profesionales como el integrador WHFast que usamos en astronomía se basan en este mismo principio para simular millones de años de evolución del Sistema Solar sin que los planetas salgan disparados."

---

### ⏱️ MINUTO 19:30 a 20:00 — CONCLUSIONES Y CIERRE

`[PASAR A SLIDE 12: Conclusiones y Cierre]`

> "Para cerrar en tiempo exacto, me gustaría resumir este trabajo en tres conclusiones principales:
>
> En primer lugar, aprendí que en computación científica, un programa puede estar perfectamente programado sin ningún error de sintaxis y aun así violar por completo las leyes de la física si el método numérico elegido no respeta la geometría del problema.
>
> En segundo lugar, comprobamos experimentalmente que los integradores simplécticos como Leapfrog son indispensables en astrodinámica, logrando siete órdenes de magnitud más de precisión en la energía con el mismo costo computacional.
>
> Y en tercer lugar, aprendí que un agente de inteligencia artificial no es un piloto automático que reemplaza al estudiante, sino un amplificador extraordinario del aprendizaje: rinde su máximo potencial cuando el estudiante mantiene el espíritu crítico, audita cada resultado con cuentas independientes y sabe guiar el proceso con rigor científico.
>
> Todo el código, las pruebas unitarias y la presentación interactiva están disponibles en el repositorio.
>
> Muchísimas gracias a todos por su atención y quedo a disposición para responder cualquier pregunta que tengan."

---

### 💡 TU MACHETE POR SI TE PREGUNTAN ALGO AL FINAL:

* **Si el profe te dice:** *"¿Por qué no usaste Runge-Kutta 4 (RK4) que es de orden 4?"*  
  **Tu respuesta:** *"RK4 tiene un error local muy chico de orden 4, pero tampoco es simpléctico. Para misiones de pocos días funciona muy bien, pero a lo largo de miles de órbitas también sufre de deriva secular de energía. Leapfrog, aunque sea de segundo orden, es superior a largo plazo porque conserva el espacio de fases."*
* **Si te preguntan:** *"¿Por qué no usaste el algoritmo de Barnes-Hut?"*  
  **Tu respuesta:** *"Porque para 3 cuerpos, calcular todos los pares cuesta únicamente 3 operaciones ($N(N-1)/2$). Barnes-Hut utiliza un árbol espacial para agrupar partículas lejanas y se vuelve necesario recién cuando simulamos galaxias o cúmulos con miles de estrellas, donde pasar de $O(N^2)$ a $O(N \log N)$ es indispensable para que la computadora no se cuelgue."*
* **Si te piden ver los tests en la terminal:**  
  Abrís PowerShell y escribís:  
  `python main.py --verificar`

---

¡Ya actualicé el archivo [**`GUION_PRESENTACION.md`**](file:///C:/Users/valen/.gemini/antigravity/scratch/nbody_sim/GUION_PRESENTACION.md) y regeneré el archivo imprimible [**`Guion_Presentacion_Valentina_Oundjian.pdf`**](file:///C:/Users/valen/.gemini/antigravity/scratch/nbody_sim/Guion_Presentacion_Valentina_Oundjian.pdf) con este texto completo! Leelo en voz alta una o dos veces y vas a ver que el tiempo te calza exacto.