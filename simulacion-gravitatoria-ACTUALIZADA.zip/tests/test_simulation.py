"""
Unit tests for the N-body orbital simulation engine.
"""

import numpy as np
import pytest

from src.body import Body
from src.physics import (
    compute_accelerations,
    compute_kinetic_energy,
    compute_potential_energy,
    compute_angular_momentum,
    compute_center_of_mass,
)
from src.integrators import step_velocity_verlet, step_yoshida4, step_rk4
from src.presets import PRESET_FACTORIES


def test_two_body_acceleration():
    # Two unit masses along x axis at x = -0.5 and x = +0.5 (distance = 1.0)
    pos = np.array([[-0.5, 0.0], [0.5, 0.0]])
    masses = np.array([1.0, 1.0])
    G = 1.0
    acc = compute_accelerations(pos, masses, G, softening=0.0)
    
    # Body 0 should accelerate towards +x with magnitude G*1/(1^2) = 1.0
    assert np.isclose(acc[0, 0], 1.0)
    assert np.isclose(acc[0, 1], 0.0)
    
    # Body 1 should accelerate towards -x with magnitude 1.0
    assert np.isclose(acc[1, 0], -1.0)
    assert np.isclose(acc[1, 1], 0.0)


def test_energy_conservation_verlet_circular_orbit():
    # Circular two-body Kepler problem
    # Mass 1 at center (M=1.0), Mass 2 in circular orbit at r=1.0, v = sqrt(G*M/r) = 1.0
    G = 1.0
    pos = np.array([[0.0, 0.0], [1.0, 0.0]])
    vel = np.array([[0.0, 0.0], [0.0, 1.0]])
    masses = np.array([1.0, 1e-4])  # Star + test particle
    fixed = np.array([True, False])  # Fix star at origin

    acc = compute_accelerations(pos, masses, G, softening=0.0)
    k0 = compute_kinetic_energy(vel, masses)
    u0 = compute_potential_energy(pos, masses, G, softening=0.0)
    e0 = k0 + u0

    dt = 0.01
    # Integrate for 5 full circular orbits: T = 2*pi*r / v = 2*pi ~ 6.28 seconds
    steps = int(2.0 * np.pi / dt) * 5
    for _ in range(steps):
        pos, vel, acc = step_velocity_verlet(pos, vel, acc, masses, fixed, dt, G, softening=0.0)

    kf = compute_kinetic_energy(vel, masses)
    uf = compute_potential_energy(pos, masses, G, softening=0.0)
    ef = kf + uf

    rel_error = abs(ef - e0) / abs(e0)
    # Symplectic integrator preserves energy to high precision
    assert rel_error < 1e-4


def test_yoshida4_high_accuracy():
    # Yoshida 4th order should conserve energy with O(dt^4) accuracy
    G = 1.0
    pos = np.array([[0.0, 0.0], [1.0, 0.0]])
    vel = np.array([[0.0, 0.0], [0.0, 1.0]])
    masses = np.array([1.0, 1e-4])
    fixed = np.array([True, False])

    acc = compute_accelerations(pos, masses, G, softening=0.0)
    e0 = compute_kinetic_energy(vel, masses) + compute_potential_energy(pos, masses, G, softening=0.0)

    dt = 0.02
    steps = int(2.0 * np.pi / dt) * 2  # 2 orbits
    for _ in range(steps):
        pos, vel, acc = step_yoshida4(pos, vel, acc, masses, fixed, dt, G, softening=0.0)

    ef = compute_kinetic_energy(vel, masses) + compute_potential_energy(pos, masses, G, softening=0.0)
    rel_error = abs(ef - e0) / abs(e0)
    assert rel_error < 1e-6


def test_angular_momentum_conservation():
    G = 1.0
    pos = np.array([[-0.5, 0.0], [0.5, 0.0]])
    vel = np.array([[0.0, -0.5], [0.0, 0.5]])
    masses = np.array([1.0, 1.0])
    fixed = np.array([False, False])
    
    l0 = compute_angular_momentum(pos, vel, masses)
    acc = compute_accelerations(pos, masses, G, softening=0.0)

    for _ in range(200):
        pos, vel, acc = step_velocity_verlet(pos, vel, acc, masses, fixed, 0.01, G, softening=0.0)

    lf = compute_angular_momentum(pos, vel, masses)
    assert np.isclose(l0, lf, atol=1e-10)


def test_all_presets_valid():
    for key, factory in PRESET_FACTORIES:
        preset = factory()
        assert len(preset.bodies) >= 2
        assert preset.G > 0
        assert preset.time_step > 0
        for b in preset.bodies:
            assert len(b.position) == 2
            assert len(b.velocity) == 2
            assert b.mass > 0
