"""
Interactive Pygame visualizer for the N-body orbital simulation.
Features:
- Pan and smooth zoom centered at cursor
- Focus following (Barycenter or specific celestial body)
- Real-time trail rendering with glowing halos
- Real-time physics sub-stepping & energy conservation monitoring
- Interactive body spawning (click & drag velocity vector)
- Preset switching, integrator switching, time acceleration
"""

import sys
import numpy as np
import pygame
from .body import Body
from .physics import (
    compute_accelerations,
    compute_kinetic_energy,
    compute_potential_energy,
    compute_angular_momentum,
    compute_center_of_mass,
)
from .integrators import INTEGRATORS
from .presets import PRESET_FACTORIES, SimulationPreset


class Visualizer:
    def __init__(self, width: int = 1280, height: int = 800):
        pygame.init()
        pygame.font.init()
        
        self.width = width
        self.height = height
        self.screen = pygame.display.set_mode((width, height), pygame.RESIZABLE)
        pygame.display.set_caption("Simulador Orbital de N-Cuerpos | Antigravity")
        self.clock = pygame.time.Clock()

        # Fonts
        self.font_title = pygame.font.SysFont("Segoe UI, Arial, sans-serif", 20, bold=True)
        self.font_body = pygame.font.SysFont("Segoe UI, Arial, sans-serif", 14)
        self.font_mono = pygame.font.SysFont("Consolas, Courier New, monospace", 13)
        self.font_small = pygame.font.SysFont("Segoe UI, Arial, sans-serif", 12)

        # Simulation & Camera state
        self.camera_offset = np.zeros(2, dtype=np.float64)  # in world units
        self.zoom = 200.0  # pixels per world unit
        self.focus_index: int | None = None  # None: free cam, -1: barycenter, 0..N: body
        
        # Physics config
        self.integrator_keys = list(INTEGRATORS.keys())
        self.current_integrator_idx = 0
        self.paused = False
        self.time_multiplier = 1.0
        self.substeps = 10
        self.sim_time = 0.0

        # Visual config
        self.show_trails = True
        self.show_labels = True
        self.show_hud = True
        self.trail_subsample = 2  # add trail point every N substeps

        # Interaction: dragging camera or creating body
        self.dragging_camera = False
        self.drag_start_screen = np.zeros(2)
        self.drag_start_cam = np.zeros(2)

        self.creating_body = False
        self.new_body_pos_world = np.zeros(2)
        self.new_body_screen_start = np.zeros(2)
        self.new_body_mass = 1e-4

        # Starfield background (random points)
        rng = np.random.default_rng(1337)
        self.stars = [
            (rng.integers(0, 3840), rng.integers(0, 2160), rng.integers(80, 220))
            for _ in range(350)
        ]

        # Load initial preset (Solar System)
        self.preset_idx = 0
        self.load_preset(self.preset_idx)

    def load_preset(self, index: int) -> None:
        """Load a simulation preset by index."""
        self.preset_idx = index % len(PRESET_FACTORIES)
        key, factory = PRESET_FACTORIES[self.preset_idx]
        self.preset: SimulationPreset = factory()
        
        # Clone bodies
        self.bodies: list[Body] = [b.clone() for b in self.preset.bodies]
        self.zoom = self.preset.default_zoom
        self.sim_time = 0.0
        self.camera_offset = np.zeros(2, dtype=np.float64)
        self.focus_index = None

        # Compute initial accelerations
        pos, vel, mass, fixed = self._get_numpy_arrays()
        acc = compute_accelerations(pos, mass, self.preset.G, self.preset.softening)
        for i, b in enumerate(self.bodies):
            b.acceleration = acc[i]
            b.clear_trail()
            b.add_trail_point()

        # Initial conserved quantities
        self.initial_energy = self._compute_total_energy()
        self.initial_angular_momentum = self._compute_angular_momentum()

    def _get_numpy_arrays(self):
        """Extract synchronized numpy arrays from body list."""
        N = len(self.bodies)
        positions = np.array([b.position for b in self.bodies], dtype=np.float64)
        velocities = np.array([b.velocity for b in self.bodies], dtype=np.float64)
        accelerations = np.array([b.acceleration for b in self.bodies], dtype=np.float64)
        masses = np.array([b.mass for b in self.bodies], dtype=np.float64)
        fixed_mask = np.array([b.fixed for b in self.bodies], dtype=bool)
        return positions, velocities, accelerations, masses, fixed_mask

    def _compute_total_energy(self) -> float:
        if not self.bodies:
            return 0.0
        pos, vel, _, mass, _ = self._get_numpy_arrays()
        k = compute_kinetic_energy(vel, mass)
        u = compute_potential_energy(pos, mass, self.preset.G, self.preset.softening)
        return k + u

    def _compute_angular_momentum(self) -> float:
        if not self.bodies:
            return 0.0
        pos, vel, _, mass, _ = self._get_numpy_arrays()
        return compute_angular_momentum(pos, vel, mass)

    def world_to_screen(self, world_pos: np.ndarray) -> np.ndarray:
        """Convert world coordinates (e.g. AU) to screen pixels."""
        center = np.array([self.width / 2.0, self.height / 2.0])
        # Invert Y for standard Cartesian coordinates
        screen_x = center[0] + (world_pos[0] - self.camera_offset[0]) * self.zoom
        screen_y = center[1] - (world_pos[1] - self.camera_offset[1]) * self.zoom
        return np.array([screen_x, screen_y])

    def screen_to_world(self, screen_pos: np.ndarray | tuple[int, int]) -> np.ndarray:
        """Convert screen pixels to world coordinates."""
        center = np.array([self.width / 2.0, self.height / 2.0])
        world_x = self.camera_offset[0] + (screen_pos[0] - center[0]) / self.zoom
        world_y = self.camera_offset[1] - (screen_pos[1] - center[1]) / self.zoom
        return np.array([world_x, world_y])

    def step_physics(self) -> None:
        """Advance the physics simulation by substeps."""
        if self.paused or not self.bodies:
            return

        dt = (self.preset.time_step * self.time_multiplier) / self.substeps
        int_key = self.integrator_keys[self.current_integrator_idx]
        _, step_func = INTEGRATORS[int_key]

        pos, vel, acc, mass, fixed = self._get_numpy_arrays()

        for s in range(self.substeps):
            pos, vel, acc = step_func(
                pos, vel, acc, mass, fixed, dt, self.preset.G, self.preset.softening
            )
            self.sim_time += dt

            # Update trails periodically
            if s % self.trail_subsample == 0 and self.show_trails:
                for i, b in enumerate(self.bodies):
                    b.add_trail_point(pos[i])

        # Write back state
        for i, b in enumerate(self.bodies):
            b.position = pos[i]
            b.velocity = vel[i]
            b.acceleration = acc[i]

    def update_camera(self) -> None:
        """Update camera offset if tracking a body or barycenter."""
        if not self.bodies:
            return

        if self.focus_index == -1:
            # Track Barycenter
            pos, vel, _, mass, _ = self._get_numpy_arrays()
            r_cm, _ = compute_center_of_mass(pos, vel, mass)
            self.camera_offset = r_cm.copy()
        elif self.focus_index is not None and 0 <= self.focus_index < len(self.bodies):
            self.camera_offset = self.bodies[self.focus_index].position.copy()

    def handle_events(self) -> bool:
        """Process keyboard and mouse events. Returns False to quit."""
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                return False

            elif event.type == pygame.VIDEORESIZE:
                self.width, self.height = event.w, event.h
                self.screen = pygame.display.set_mode((event.w, event.h), pygame.RESIZABLE)

            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    return False
                elif event.key == pygame.K_SPACE:
                    self.paused = not self.paused
                elif event.key == pygame.K_r:
                    self.load_preset(self.preset_idx)
                elif event.key == pygame.K_t:
                    self.show_trails = not self.show_trails
                elif event.key == pygame.K_c:
                    for b in self.bodies:
                        b.clear_trail()
                elif event.key == pygame.K_h:
                    self.show_hud = not self.show_hud
                elif event.key == pygame.K_l:
                    self.show_labels = not self.show_labels
                elif event.key == pygame.K_i:
                    self.current_integrator_idx = (self.current_integrator_idx + 1) % len(self.integrator_keys)
                elif event.key == pygame.K_f:
                    # Cycle focus: None -> -1 (Barycenter) -> 0..N-1 -> None
                    if self.focus_index is None:
                        self.focus_index = -1
                    elif self.focus_index == -1:
                        self.focus_index = 0 if self.bodies else None
                    else:
                        self.focus_index += 1
                        if self.focus_index >= len(self.bodies):
                            self.focus_index = None
                elif event.key in (pygame.K_1, pygame.K_2, pygame.K_3, pygame.K_4, pygame.K_5):
                    idx = event.key - pygame.K_1
                    self.load_preset(idx)
                elif event.key in (pygame.K_PLUS, pygame.K_KP_PLUS, pygame.K_EQUALS):
                    self.time_multiplier = min(self.time_multiplier * 1.5, 50.0)
                elif event.key in (pygame.K_MINUS, pygame.K_KP_MINUS):
                    self.time_multiplier = max(self.time_multiplier / 1.5, 0.05)
                elif event.key in (pygame.K_PERIOD, pygame.K_s):
                    # Single step while paused
                    was_paused = self.paused
                    self.paused = False
                    self.step_physics()
                    self.paused = was_paused

            elif event.type == pygame.MOUSEBUTTONDOWN:
                if event.button == 1:  # Left click: start body creation
                    self.creating_body = True
                    self.new_body_screen_start = np.array(event.pos, dtype=np.float64)
                    self.new_body_pos_world = self.screen_to_world(event.pos)
                elif event.button in (2, 3):  # Middle or Right click: start panning camera
                    self.dragging_camera = True
                    self.drag_start_screen = np.array(event.pos, dtype=np.float64)
                    self.drag_start_cam = self.camera_offset.copy()
                    self.focus_index = None  # Free camera when manually panning

                elif event.button == 4:  # Wheel up: zoom in
                    self._zoom_at(event.pos, 1.15)
                elif event.button == 5:  # Wheel down: zoom out
                    self._zoom_at(event.pos, 1.0 / 1.15)

            elif event.type == pygame.MOUSEBUTTONUP:
                if event.button == 1 and self.creating_body:
                    self.creating_body = False
                    # Velocity vector proportional to drag distance
                    current_screen = np.array(event.pos, dtype=np.float64)
                    drag_vec_px = current_screen - self.new_body_screen_start
                    
                    # Scale drag pixels to world velocity:
                    # Invert Y because screen Y goes down, world Y goes up
                    vel_world = np.array([drag_vec_px[0], -drag_vec_px[1]]) * (2.0 / self.zoom)

                    # Create and append custom body
                    new_b = Body(
                        name=f"Cuerpo #{len(self.bodies)+1}",
                        mass=self.new_body_mass,
                        position=self.new_body_pos_world,
                        velocity=vel_world,
                        color=(120, 240, 220),
                        radius_pixels=4,
                        max_trail_points=500,
                    )
                    self.bodies.append(new_b)

                elif event.button in (2, 3):
                    self.dragging_camera = False

            elif event.type == pygame.MOUSEMOTION:
                if self.dragging_camera:
                    delta_px = np.array(event.pos, dtype=np.float64) - self.drag_start_screen
                    # Adjust camera offset
                    self.camera_offset[0] = self.drag_start_cam[0] - delta_px[0] / self.zoom
                    self.camera_offset[1] = self.drag_start_cam[1] + delta_px[1] / self.zoom

        return True

    def _zoom_at(self, screen_pos: tuple[int, int], factor: float) -> None:
        """Zoom centered at cursor position."""
        world_before = self.screen_to_world(screen_pos)
        self.zoom = float(np.clip(self.zoom * factor, 5.0, 50000.0))
        world_after = self.screen_to_world(screen_pos)
        # Shift camera offset so mouse remains fixed in world space
        self.camera_offset += (world_before - world_after)

    def render(self) -> None:
        """Render background, stars, trails, bodies, HUD, and overlays."""
        # 1. Dark space background
        self.screen.fill((8, 10, 18))

        # 2. Subtle background stars
        w, h = self.width, self.height
        for sx, sy, lum in self.stars:
            px = (sx - int(self.camera_offset[0] * 5.0)) % w
            py = (sy + int(self.camera_offset[1] * 5.0)) % h
            self.screen.set_at((px, py), (lum, lum, min(255, lum + 30)))

        # 3. Draw grid axes / origin crosshair
        orig_scr = self.world_to_screen(np.zeros(2))
        if 0 <= orig_scr[0] <= w and 0 <= orig_scr[1] <= h:
            pygame.draw.line(self.screen, (25, 30, 45), (orig_scr[0], 0), (orig_scr[0], h), 1)
            pygame.draw.line(self.screen, (25, 30, 45), (0, orig_scr[1]), (w, orig_scr[1]), 1)

        # 4. Render Trails
        if self.show_trails:
            for b in self.bodies:
                if len(b.trail) > 1:
                    points = [self.world_to_screen(p) for p in b.trail]
                    n_pts = len(points)
                    # Draw in segments with progressive alpha/fading
                    r, g, bl = b.color
                    for i in range(n_pts - 1):
                        alpha_factor = (i + 1) / n_pts
                        color = (int(r * alpha_factor * 0.7), int(g * alpha_factor * 0.7), int(bl * alpha_factor * 0.7))
                        p1 = (int(points[i][0]), int(points[i][1]))
                        p2 = (int(points[i + 1][0]), int(points[i + 1][1]))
                        # Only draw if on screen or close
                        if (-100 <= p1[0] <= w + 100 and -100 <= p1[1] <= h + 100) or \
                           (-100 <= p2[0] <= w + 100 and -100 <= p2[1] <= h + 100):
                            pygame.draw.line(self.screen, color, p1, p2, 1)

        # 5. Render Bodies with Halo
        for i, b in enumerate(self.bodies):
            scr = self.world_to_screen(b.position)
            sx, sy = int(scr[0]), int(scr[1])

            if -50 <= sx <= w + 50 and -50 <= sy <= h + 50:
                rad = max(2, b.radius_pixels)
                # Outer glow surface
                glow_radius = rad * 3
                glow_surf = pygame.Surface((glow_radius * 2, glow_radius * 2), pygame.SRCALPHA)
                r, g, bl = b.color
                pygame.draw.circle(
                    glow_surf,
                    (r, g, bl, 45),
                    (glow_radius, glow_radius),
                    glow_radius
                )
                pygame.draw.circle(
                    glow_surf,
                    (r, g, bl, 90),
                    (glow_radius, glow_radius),
                    rad + 2
                )
                self.screen.blit(glow_surf, (sx - glow_radius, sy - glow_radius))

                # Solid core
                pygame.draw.circle(self.screen, b.color, (sx, sy), rad)

                # Focus indicator
                if self.focus_index == i:
                    pygame.draw.circle(self.screen, (255, 255, 255), (sx, sy), rad + 6, 1)

                # Label
                if self.show_labels:
                    label = self.font_small.render(b.name, True, (200, 210, 225))
                    self.screen.blit(label, (sx + rad + 4, sy - 7))

        # 6. Render Barycenter if active
        if len(self.bodies) > 1:
            pos, vel, _, mass, _ = self._get_numpy_arrays()
            r_cm, _ = compute_center_of_mass(pos, vel, mass)
            cm_scr = self.world_to_screen(r_cm)
            cx, cy = int(cm_scr[0]), int(cm_scr[1])
            if 0 <= cx <= w and 0 <= cy <= h:
                # Small yellow cross for barycenter
                pygame.draw.line(self.screen, (255, 255, 100), (cx - 5, cy), (cx + 5, cy), 1)
                pygame.draw.line(self.screen, (255, 255, 100), (cx, cy - 5), (cx, cy + 5), 1)
                if self.focus_index == -1:
                    pygame.draw.circle(self.screen, (255, 255, 100), (cx, cy), 9, 1)
                    lbl = self.font_small.render("Centro de Masa", True, (255, 255, 140))
                    self.screen.blit(lbl, (cx + 8, cy - 7))

        # 7. Creation Preview Line
        if self.creating_body:
            start_px = (int(self.new_body_screen_start[0]), int(self.new_body_screen_start[1]))
            mouse_px = pygame.mouse.get_pos()
            pygame.draw.circle(self.screen, (100, 255, 200), start_px, 5)
            pygame.draw.line(self.screen, (100, 255, 200), start_px, mouse_px, 2)
            # Arrow head
            pygame.draw.circle(self.screen, (255, 255, 100), mouse_px, 3)

        # 8. Render HUD
        if self.show_hud:
            self._render_hud()

        pygame.display.flip()

    def _render_hud(self) -> None:
        """Render information dashboard and controls overlay."""
        # Top-left info card
        card_w, card_h = 360, 220
        panel = pygame.Surface((card_w, card_h), pygame.SRCALPHA)
        panel.fill((14, 18, 30, 215))
        pygame.draw.rect(panel, (50, 70, 110, 240), (0, 0, card_w, card_h), 1, border_radius=8)
        self.screen.blit(panel, (15, 15))

        # Title
        title_surf = self.font_title.render(self.preset.name, True, (255, 220, 100))
        self.screen.blit(title_surf, (25, 22))

        # Subtitle / description
        desc_surf = self.font_small.render(self.preset.description[:48], True, (160, 175, 195))
        self.screen.blit(desc_surf, (25, 48))

        # Energy & Metrics
        current_energy = self._compute_total_energy()
        current_L = self._compute_angular_momentum()
        
        delta_e = abs(current_energy - self.initial_energy)
        rel_err = (delta_e / abs(self.initial_energy)) if self.initial_energy != 0 else 0.0

        int_name, _ = INTEGRATORS[self.integrator_keys[self.current_integrator_idx]]
        
        # Focus text
        if self.focus_index is None:
            focus_str = "Cámara Libre"
        elif self.focus_index == -1:
            focus_str = "Barycentro (Centro de Masa)"
        else:
            focus_str = f"Seguir: {self.bodies[self.focus_index].name}"

        lines = [
            f"Integrador:  {int_name}",
            f"Tiempo Sim:  {self.sim_time:8.3f} {self.preset.time_unit_name} (x{self.time_multiplier:.2f})",
            f"Energía E:   {current_energy:+.6e}",
            f"Error dE/E0: {rel_err:+.3e} ({rel_err*100:.6f}%)",
            f"Momento Lz:  {current_L:+.6e}",
            f"Cuerpos:     {len(self.bodies)} activos | {focus_str}",
            f"Estado:      {'PAUSADO (ESPACIO)' if self.paused else 'CORRIENDO'}",
        ]

        y = 70
        for line in lines:
            color = (230, 235, 245)
            if "Error" in line:
                # Color code error: green if small, yellow if medium, red if high
                color = (120, 255, 150) if rel_err < 1e-3 else (255, 200, 80) if rel_err < 1e-1 else (255, 90, 90)
            elif "PAUSADO" in line:
                color = (255, 210, 80)
            surf = self.font_mono.render(line, True, color)
            self.screen.blit(surf, (25, y))
            y += 20

        # Bottom-left controls quick guide
        ctrl_w, ctrl_h = 420, 110
        ctrl_panel = pygame.Surface((ctrl_w, ctrl_h), pygame.SRCALPHA)
        ctrl_panel.fill((14, 18, 30, 200))
        pygame.draw.rect(ctrl_panel, (40, 60, 90, 220), (0, 0, ctrl_w, ctrl_h), 1, border_radius=6)
        self.screen.blit(ctrl_panel, (15, self.height - ctrl_h - 15))

        shortcuts = [
            "[1-5] Presets: 1:Solar  2:Fig-8  3:Troyanos  4:Burrau  5:Binario",
            "[I] Cambiar Integrador (Verlet / Yoshida / RK4 / Euler)",
            "[F] Fijar Cámara | [Rueda] Zoom | [Click Der] Mover Cámara",
            "[Click Izq + Arrastrar] Lanzar nuevo cuerpo u órbita",
            "[ESPACIO] Pausar | [+/-] Velocidad | [T] Rastros | [R] Reiniciar",
        ]
        cy = self.height - ctrl_h - 10
        for sc in shortcuts:
            sc_surf = self.font_small.render(sc, True, (170, 190, 215))
            self.screen.blit(sc_surf, (25, cy))
            cy += 19

    def run(self) -> None:
        """Main simulation and rendering loop."""
        running = True
        while running:
            running = self.handle_events()
            self.step_physics()
            self.update_camera()
            self.render()
            self.clock.tick(60)

        pygame.quit()
