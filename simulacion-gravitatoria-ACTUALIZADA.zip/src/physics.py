"""
Physics engine: gravitational force calculations, energies, and invariants.
"""

import numpy as np
from .body import Body


def compute_accelerations(
    positions: np.ndarray,
    masses: np.ndarray,
    G: float,
    softening: float = 1e-4,
) -> np.ndarray:
    """
    Vectorized computation of gravitational accelerations for N bodies in 2D.
    
    positions: array of shape (N, 2)
    masses: array of shape (N,)
    G: gravitational constant
    softening: softening factor epsilon to avoid singularities when r -> 0
    
    Returns:
        accelerations: array of shape (N, 2)
    """
    N = len(masses)
    if N <= 1:
        return np.zeros_like(positions)

    # dx[i, j] = pos[j, 0] - pos[i, 0]
    # dy[i, j] = pos[j, 1] - pos[i, 1]
    # shape: (N, N, 2)
    diff = positions[np.newaxis, :, :] - positions[:, np.newaxis, :]
    
    # r^2 = dx^2 + dy^2 + softening^2
    dist_sq = np.sum(diff**2, axis=-1) + softening**2
    
    # Zero out diagonal to avoid self-force
    np.fill_diagonal(dist_sq, np.inf)
    
    # 1 / dist^3
    inv_dist_cube = dist_sq ** (-1.5)
    
    # Acceleration contribution: G * m_j * (r_j - r_i) / dist^3
    # masses shape (N,) -> (1, N, 1)
    force_factors = G * masses[np.newaxis, :, np.newaxis] * inv_dist_cube[:, :, np.newaxis]
    
    # Sum over all j != i
    accelerations = np.sum(diff * force_factors, axis=1)
    return accelerations


def compute_kinetic_energy(velocities: np.ndarray, masses: np.ndarray) -> float:
    """K = 0.5 * sum(m_i * |v_i|^2)"""
    v_sq = np.sum(velocities**2, axis=1)
    return float(0.5 * np.sum(masses * v_sq))


def compute_potential_energy(
    positions: np.ndarray,
    masses: np.ndarray,
    G: float,
    softening: float = 1e-4,
) -> float:
    """U = - sum_{i < j} G * m_i * m_j / sqrt(r_{ij}^2 + eps^2)"""
    N = len(masses)
    if N <= 1:
        return 0.0

    diff = positions[np.newaxis, :, :] - positions[:, np.newaxis, :]
    dist = np.sqrt(np.sum(diff**2, axis=-1) + softening**2)
    
    # Mass pairs matrix: m_i * m_j
    m_matrix = np.outer(masses, masses)
    
    # Consider only upper triangle (i < j)
    tri_i, tri_j = np.triu_indices(N, k=1)
    u_pairs = -G * m_matrix[tri_i, tri_j] / dist[tri_i, tri_j]
    return float(np.sum(u_pairs))


def compute_angular_momentum(
    positions: np.ndarray,
    velocities: np.ndarray,
    masses: np.ndarray,
) -> float:
    """Total angular momentum L_z = sum(m_i * (x_i * v_{y,i} - y_i * v_{x,i}))"""
    cross_2d = positions[:, 0] * velocities[:, 1] - positions[:, 1] * velocities[:, 0]
    return float(np.sum(masses * cross_2d))


def compute_center_of_mass(
    positions: np.ndarray,
    velocities: np.ndarray,
    masses: np.ndarray,
) -> tuple[np.ndarray, np.ndarray]:
    """Compute center of mass position and velocity (R_cm, V_cm)."""
    total_mass = np.sum(masses)
    if total_mass == 0:
        return np.zeros(2), np.zeros(2)
    r_cm = np.sum(positions * masses[:, np.newaxis], axis=0) / total_mass
    v_cm = np.sum(velocities * masses[:, np.newaxis], axis=0) / total_mass
    return r_cm, v_cm
