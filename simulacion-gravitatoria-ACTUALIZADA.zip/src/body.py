"""
Representation of a celestial body in the N-body simulation.
"""

from collections import deque
import numpy as np


class Body:
    """Represents a celestial body with physical properties and visualization state."""

    def __init__(
        self,
        name: str,
        mass: float,
        position: np.ndarray | list[float],
        velocity: np.ndarray | list[float],
        color: tuple[int, int, int] = (255, 255, 255),
        radius_pixels: int = 5,
        max_trail_points: int = 400,
        fixed: bool = False,
    ):
        self.name = name
        self.mass = float(mass)
        self.position = np.array(position, dtype=np.float64)
        self.velocity = np.array(velocity, dtype=np.float64)
        self.acceleration = np.zeros(2, dtype=np.float64)
        
        # Rendering attributes
        self.color = color
        self.radius_pixels = radius_pixels
        self.fixed = fixed
        self.trail: deque[np.ndarray] = deque(maxlen=max_trail_points)
        self.max_trail_points = max_trail_points

    def add_trail_point(self, pos: np.ndarray | None = None) -> None:
        """Record the current position into the trail history."""
        p = self.position if pos is None else pos
        self.trail.append(p.copy())

    def clear_trail(self) -> None:
        """Clear all historical trail points."""
        self.trail.clear()

    def clone(self) -> "Body":
        """Create a deep copy of the body."""
        b = Body(
            name=self.name,
            mass=self.mass,
            position=self.position.copy(),
            velocity=self.velocity.copy(),
            color=self.color,
            radius_pixels=self.radius_pixels,
            max_trail_points=self.max_trail_points,
            fixed=self.fixed,
        )
        b.acceleration = self.acceleration.copy()
        return b
