"""
Curated orbital presets and initial conditions for the N-body simulation.
"""

from dataclasses import dataclass
import numpy as np
from .body import Body


@dataclass
class SimulationPreset:
    name: str
    description: str
    G: float
    time_step: float
    time_unit_name: str
    scale_label: str
    bodies: list[Body]
    softening: float = 1e-4
    default_zoom: float = 200.0


def make_solar_system() -> SimulationPreset:
    """
    Inner Solar System (Sun, Mercury, Venus, Earth, Moon, Mars).
    Units:
      Length: Astronomical Units (AU)
      Time: Years (1 year = 365.25 days)
      Mass: Solar Masses (M_sun = 1.0)
      G = 4 * pi^2 ~ 39.47841760435743
    """
    G = 4.0 * np.pi**2
    
    # Body parameters: (name, mass_in_M_sun, semi_major_axis_AU, orbital_period_years, color, radius_px)
    # v_circ = 2 * pi * sqrt(M_sun / a)
    bodies_data = [
        ("Sol", 1.0, 0.0, 0.0, (255, 220, 60), 12, 500),
        ("Mercurio", 1.66e-7, 0.387, 0.241, (180, 180, 180), 4, 300),
        ("Venus", 2.45e-6, 0.723, 0.615, (230, 190, 130), 6, 400),
        ("Tierra", 3.003e-6, 1.000, 1.000, (80, 160, 255), 7, 600),
        ("Luna", 3.69e-8, 1.000 + 0.00257, 1.000, (220, 220, 230), 2, 200),
        ("Marte", 3.23e-7, 1.524, 1.881, (240, 100, 70), 5, 500),
    ]

    bodies = []
    
    # Sun at center
    sun = Body(
        name="Sol",
        mass=1.0,
        position=[0.0, 0.0],
        velocity=[0.0, 0.0],
        color=(255, 220, 60),
        radius_pixels=12,
        max_trail_points=600,
    )
    bodies.append(sun)

    # Mercury
    r_mer = 0.387
    v_mer = 2.0 * np.pi * np.sqrt(1.0 / r_mer)
    bodies.append(Body("Mercurio", 1.66e-7, [r_mer, 0.0], [0.0, v_mer], (185, 185, 190), 4, 350))

    # Venus
    r_ven = 0.723
    v_ven = 2.0 * np.pi * np.sqrt(1.0 / r_ven)
    bodies.append(Body("Venus", 2.45e-6, [0.0, r_ven], [-v_ven, 0.0], (230, 200, 140), 6, 450))

    # Earth
    r_ear = 1.000
    v_ear = 2.0 * np.pi * np.sqrt(1.0 / r_ear)
    bodies.append(Body("Tierra", 3.003e-6, [-r_ear, 0.0], [0.0, -v_ear], (80, 170, 255), 7, 700))

    # Moon (orbiting Earth)
    # Distance: ~384,400 km = 0.00257 AU
    # Moon orbital speed relative to Earth: sqrt(G * M_earth / r_moon)
    r_moon_rel = 0.0035  # slightly magnified for visual clearance
    v_moon_rel = np.sqrt(G * 3.003e-6 / r_moon_rel)
    bodies.append(Body(
        "Luna",
        3.69e-8,
        [-r_ear - r_moon_rel, 0.0],
        [0.0, -v_ear - v_moon_rel],
        (220, 225, 230),
        3,
        150
    ))

    # Mars
    r_mar = 1.524
    v_mar = 2.0 * np.pi * np.sqrt(1.0 / r_mar)
    bodies.append(Body("Marte", 3.23e-7, [0.0, -r_mar], [v_mar, 0.0], (240, 105, 75), 5, 600))

    # Center-of-mass correction to ensure zero total momentum
    total_mass = sum(b.mass for b in bodies)
    v_cm = sum(b.mass * b.velocity for b in bodies) / total_mass
    for b in bodies:
        b.velocity -= v_cm

    return SimulationPreset(
        name="Sistema Solar Interior",
        description="Sol, Mercurio, Venus, Tierra con Luna, y Marte (unidades reales: AU, M_sun, Años)",
        G=G,
        time_step=0.001,  # ~8.7 horas por paso
        time_unit_name="años",
        scale_label="1 AU",
        bodies=bodies,
        softening=1e-5,
        default_zoom=240.0,
    )


def make_figure_eight() -> SimulationPreset:
    """
    Chenciner & Montgomery / Cris Moore Figure-8 Three-Body choreography.
    Three equal mass bodies in stable periodic choreographic orbit.
    """
    G = 1.0
    m = 1.0
    
    # Precise initial conditions
    x1, y1 = -0.97000436, 0.24308753
    vx1, vy1 = 0.46620531, 0.43236573
    
    bodies = [
        Body("Cuerpo A", m, [x1, y1], [vx1, vy1], (70, 230, 255), 8, 800),
        Body("Cuerpo B", m, [-x1, -y1], [vx1, vy1], (255, 90, 160), 8, 800),
        Body("Cuerpo C", m, [0.0, 0.0], [-2.0 * vx1, -2.0 * vy1], (255, 220, 80), 8, 800),
    ]

    return SimulationPreset(
        name="Problema de 3 Cuerpos: Figura 8",
        description="Solución coreográfica periódica de Chenciner-Montgomery (G=1, masas iguales)",
        G=G,
        time_step=0.002,
        time_unit_name="u.t.",
        scale_label="1 u.l.",
        bodies=bodies,
        softening=1e-6,
        default_zoom=250.0,
    )


def make_lagrange_trojans() -> SimulationPreset:
    """
    Restricted 3-body system: Sun, Jupiter-analog, and Trojan asteroids librating around L4 and L5.
    """
    G = 1.0
    M_sun = 1.0
    M_jup = 0.02
    R = 1.0
    v_jup = np.sqrt(G * (M_sun + M_jup) / R)

    bodies = [
        Body("Estrella Madre", M_sun, [0.0, 0.0], [0.0, 0.0], (255, 210, 60), 12, 300),
        Body("Gigante Gaseoso", M_jup, [R, 0.0], [0.0, v_jup], (230, 140, 80), 8, 700),
    ]

    # L4 is at +60 deg, L5 at -60 deg
    rng = np.random.default_rng(42)
    # Spawn a cluster of 12 Trojan asteroids around L4
    angle_l4 = np.pi / 3.0
    for i in range(10):
        # Slightly perturbed around L4
        r_pert = R * (1.0 + rng.uniform(-0.03, 0.03))
        th_pert = angle_l4 + rng.uniform(-0.06, 0.06)
        x = r_pert * np.cos(th_pert)
        y = r_pert * np.sin(th_pert)
        
        # Keplerian tangent velocity with slight libration perturbation
        v_mag = np.sqrt(G * M_sun / r_pert) * (1.0 + rng.uniform(-0.01, 0.01))
        vx = -v_mag * np.sin(th_pert)
        vy = v_mag * np.cos(th_pert)
        
        bodies.append(Body(f"Troyano L4-{i+1}", 1e-8, [x, y], [vx, vy], (140, 220, 160), 3, 200))

    # L5 cluster
    angle_l5 = -np.pi / 3.0
    for i in range(6):
        r_pert = R * (1.0 + rng.uniform(-0.03, 0.03))
        th_pert = angle_l5 + rng.uniform(-0.06, 0.06)
        x = r_pert * np.cos(th_pert)
        y = r_pert * np.sin(th_pert)
        v_mag = np.sqrt(G * M_sun / r_pert) * (1.0 + rng.uniform(-0.01, 0.01))
        vx = -v_mag * np.sin(th_pert)
        vy = v_mag * np.cos(th_pert)
        bodies.append(Body(f"Troyano L5-{i+1}", 1e-8, [x, y], [vx, vy], (180, 160, 240), 3, 200))

    # Barycenter correction
    total_m = sum(b.mass for b in bodies)
    v_cm = sum(b.mass * b.velocity for b in bodies) / total_m
    r_cm = sum(b.mass * b.position for b in bodies) / total_m
    for b in bodies:
        b.velocity -= v_cm
        b.position -= r_cm

    return SimulationPreset(
        name="Puntos de Lagrange (Troyanos L4 / L5)",
        description="Estrella, planeta gigante y asteroides librando en los puntos de equilibrio L4 y L5",
        G=G,
        time_step=0.002,
        time_unit_name="u.t.",
        scale_label="1 u.l.",
        bodies=bodies,
        softening=1e-5,
        default_zoom=300.0,
    )


def make_pythagorean_problem() -> SimulationPreset:
    """
    Burrau's Problem (Pythagorean 3-body problem):
    Masses 3, 4, 5 at the vertices of a 3-4-5 right triangle, starting from REST!
    Exhibits intense chaotic interactions and gravitational slingshots.
    """
    G = 1.0
    bodies = [
        Body("Masa 3", 3.0, [1.0, 3.0], [0.0, 0.0], (255, 90, 90), 8, 900),
        Body("Masa 4", 4.0, [-2.0, -1.0], [0.0, 0.0], (90, 240, 120), 9, 900),
        Body("Masa 5", 5.0, [1.0, -1.0], [0.0, 0.0], (100, 160, 255), 10, 900),
    ]

    return SimulationPreset(
        name="Problema Pitagórico de Burrau",
        description="Masas 3, 4 y 5 en reposo sobre un triángulo 3-4-5. Evolución altamente caótica.",
        G=G,
        time_step=0.001,
        time_unit_name="u.t.",
        scale_label="1 u.l.",
        bodies=bodies,
        softening=1e-4,
        default_zoom=70.0,
    )


def make_circumbinary_system() -> SimulationPreset:
    """
    Binary Star System with a stable circumbinary planet ('Tatooine').
    """
    G = 1.0
    m_star = 0.5
    d_binary = 0.5
    v_star = np.sqrt(G * m_star / (2.0 * d_binary))

    bodies = [
        Body("Estrella Alpha", m_star, [-d_binary / 2.0, 0.0], [0.0, -v_star], (255, 180, 50), 9, 500),
        Body("Estrella Beta", m_star, [d_binary / 2.0, 0.0], [0.0, v_star], (255, 100, 70), 9, 500),
    ]

    # Planet far enough to be dynamically stable (r > 3-4 times binary separation)
    r_planet = 1.6
    v_planet = np.sqrt(G * (2 * m_star) / r_planet)
    bodies.append(Body("Planeta Circumbinario", 1e-5, [0.0, r_planet], [-v_planet, 0.0], (100, 220, 240), 5, 700))

    return SimulationPreset(
        name="Sistema Binario Circumbinario",
        description="Dos estrellas en órbita mutua con un exoplaneta orbitando el centro de masa conjunto",
        G=G,
        time_step=0.002,
        time_unit_name="u.t.",
        scale_label="1 u.l.",
        bodies=bodies,
        softening=1e-5,
        default_zoom=220.0,
    )


PRESET_FACTORIES = [
    ("1", make_solar_system),
    ("2", make_figure_eight),
    ("3", make_lagrange_trojans),
    ("4", make_pythagorean_problem),
    ("5", make_circumbinary_system),
]
