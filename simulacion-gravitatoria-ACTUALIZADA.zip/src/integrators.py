"""
Numerical integrators for orbital mechanics:
Symplectic integrators (Velocity Verlet, Yoshida 4th) and non-symplectic benchmarks (RK4, Euler).
"""

from typing import Callable
import numpy as np
from .physics import compute_accelerations


def step_velocity_verlet(
    positions: np.ndarray,
    velocities: np.ndarray,
    accelerations: np.ndarray,
    masses: np.ndarray,
    fixed_mask: np.ndarray,
    dt: float,
    G: float,
    softening: float,
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """
    2nd-order Symplectic Velocity Verlet integration step.
    
    1. v(t + dt/2) = v(t) + 0.5 * a(t) * dt
    2. r(t + dt)   = r(t) + v(t + dt/2) * dt
    3. a(t + dt)   = compute_accelerations(r(t + dt))
    4. v(t + dt)   = v(t + dt/2) + 0.5 * a(t + dt) * dt
    """
    # 1. Half-step velocity
    v_half = velocities + 0.5 * accelerations * dt
    v_half[fixed_mask] = 0.0

    # 2. Full-step position
    new_positions = positions.copy()
    new_positions[~fixed_mask] += v_half[~fixed_mask] * dt

    # 3. New acceleration
    new_accelerations = compute_accelerations(new_positions, masses, G, softening)
    new_accelerations[fixed_mask] = 0.0

    # 4. Final velocity half-step
    new_velocities = v_half + 0.5 * new_accelerations * dt
    new_velocities[fixed_mask] = 0.0

    return new_positions, new_velocities, new_accelerations


def step_yoshida4(
    positions: np.ndarray,
    velocities: np.ndarray,
    accelerations: np.ndarray,
    masses: np.ndarray,
    fixed_mask: np.ndarray,
    dt: float,
    G: float,
    softening: float,
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """
    4th-order Symplectic Integrator (Yoshida 1990).
    Constructed from composition of 2nd-order leapfrog steps.
    Preserves symplectic 2-form with O(dt^4) global error.
    """
    cbrt2 = 2.0 ** (1.0 / 3.0)
    w1 = 1.0 / (2.0 - cbrt2)
    w0 = -cbrt2 / (2.0 - cbrt2)
    
    # Substep weights for drift and kick
    c = np.array([w1 / 2.0, (w0 + w1) / 2.0, (w0 + w1) / 2.0, w1 / 2.0])
    d = np.array([w1, w0, w1])

    pos = positions.copy()
    vel = velocities.copy()

    for i in range(3):
        # Drift
        pos[~fixed_mask] += c[i] * vel[~fixed_mask] * dt
        # Kick
        acc = compute_accelerations(pos, masses, G, softening)
        acc[fixed_mask] = 0.0
        vel[~fixed_mask] += d[i] * acc[~fixed_mask] * dt

    # Final drift
    pos[~fixed_mask] += c[3] * vel[~fixed_mask] * dt

    final_acc = compute_accelerations(pos, masses, G, softening)
    final_acc[fixed_mask] = 0.0
    vel[fixed_mask] = 0.0

    return pos, vel, final_acc


def step_rk4(
    positions: np.ndarray,
    velocities: np.ndarray,
    accelerations: np.ndarray,
    masses: np.ndarray,
    fixed_mask: np.ndarray,
    dt: float,
    G: float,
    softening: float,
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """
    Classic 4th-order Runge-Kutta integrator (non-symplectic benchmark).
    """
    # k1
    k1_v = velocities
    k1_a = compute_accelerations(positions, masses, G, softening)
    k1_a[fixed_mask] = 0.0

    # k2
    pos_k2 = positions + 0.5 * dt * k1_v
    pos_k2[fixed_mask] = positions[fixed_mask]
    k2_v = velocities + 0.5 * dt * k1_a
    k2_v[fixed_mask] = 0.0
    k2_a = compute_accelerations(pos_k2, masses, G, softening)
    k2_a[fixed_mask] = 0.0

    # k3
    pos_k3 = positions + 0.5 * dt * k2_v
    pos_k3[fixed_mask] = positions[fixed_mask]
    k3_v = velocities + 0.5 * dt * k2_a
    k3_v[fixed_mask] = 0.0
    k3_a = compute_accelerations(pos_k3, masses, G, softening)
    k3_a[fixed_mask] = 0.0

    # k4
    pos_k4 = positions + dt * k3_v
    pos_k4[fixed_mask] = positions[fixed_mask]
    k4_v = velocities + dt * k3_a
    k4_v[fixed_mask] = 0.0
    k4_a = compute_accelerations(pos_k4, masses, G, softening)
    k4_a[fixed_mask] = 0.0

    new_pos = positions.copy()
    new_pos[~fixed_mask] += (dt / 6.0) * (k1_v + 2.0 * k2_v + 2.0 * k3_v + k4_v)[~fixed_mask]

    new_vel = velocities.copy()
    new_vel[~fixed_mask] += (dt / 6.0) * (k1_a + 2.0 * k2_a + 2.0 * k3_a + k4_a)[~fixed_mask]

    new_acc = compute_accelerations(new_pos, masses, G, softening)
    new_acc[fixed_mask] = 0.0

    return new_pos, new_vel, new_acc


def step_euler(
    positions: np.ndarray,
    velocities: np.ndarray,
    accelerations: np.ndarray,
    masses: np.ndarray,
    fixed_mask: np.ndarray,
    dt: float,
    G: float,
    softening: float,
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """
    Standard Forward Euler method (1st order, non-symplectic).
    Included for educational comparison to demonstrate orbital instability.
    """
    new_positions = positions.copy()
    new_positions[~fixed_mask] += velocities[~fixed_mask] * dt

    new_velocities = velocities.copy()
    new_velocities[~fixed_mask] += accelerations[~fixed_mask] * dt

    new_acc = compute_accelerations(new_positions, masses, G, softening)
    new_acc[fixed_mask] = 0.0

    return new_positions, new_velocities, new_acc


INTEGRATORS: dict[str, tuple[str, Callable]] = {
    "verlet": ("Velocity Verlet (2nd Order Symplectic)", step_velocity_verlet),
    "yoshida": ("Yoshida (4th Order Symplectic)", step_yoshida4),
    "rk4": ("Runge-Kutta 4 (Classic 4th Order)", step_rk4),
    "euler": ("Forward Euler (1st Order - Unstable)", step_euler),
}
